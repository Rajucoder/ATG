<?php
   session_start();
   include "includes/connection.php";
//   include('includes/slider.php');
   if(isset($_POST['recsubmit']))
   {
    $recemail=$_POST['recemail'];
    $recpassword=$_POST['recpassword'];
    $recconfpassword =$_POST['recconfpassword'];
    $today = date("Y/m/d");
    if($recpassword==$recconfpassword){
      $sql = $pdo->prepare("select * from recruiter_basic where email = :email");
      $sql->bindParam(':email',$recemail);
      $sql->execute();
      $count = $sql->rowCount();
     if($count==0){
    $sql ="insert into recruiter_basic(email,password,registration_date) values(:email,:password,:today)";
    $query= $pdo -> prepare($sql);
    $query-> bindParam(':email', $recemail);
    $query-> bindParam(':password', $recpassword);
    $query->bindParam(':today',$today);
    $query-> execute();
    
    echo "<script>alert('Registered Successfully.');
    document.location = 'index_recruiter.php';
    </script>";}
    else{
      echo "<script>alert('email already used!!');</script>";
    }
    }
    else{
      echo "<script>alert('passwords should be matched!!');</script>";
    }
  
   }
?>


<!DOCTYPE html>
<html>
<head>
  <title>Vault Board</title>
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <link rel="stylesheet" type="text/css" href="assets/bootstrap-tagsinput.css">
      <link rel="stylesheet" type="text/css" href="assets/bootstrap-multiselect.css">
      <link rel="stylesheet" type="text/css" href="assets/styles.css">
      <link rel="stylesheet" type="text/css" href="assets/bootstrap-tagsinput.css">
      <link rel="stylesheet" type="text/css" href="assets/bootstrap-tagsinput.css">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>      
      <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>      
      <script type="text/javascript" src="../assets/bootstrap-multiselect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
     <script type="text/javascript" src="../assets/bootstrap-tagsinput.js"></script>    
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
     <script type="text/javascript" src="assets/bootstrap-tagsinput.js"></script>
     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.css">
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
  <style type="text/css">
    body html{
      margin:0;
      padding:0;}
     .container1{
                background-image: url(images/home_background.jpg);
                background-repeat: no-repeat;
                padding-top: 0px;
                background-size: cover;
                background-position: center center;
                width: 100%;
                height: 100vh;
            }
             .overlay{
                background: #0000008a;
                width: 100%;
                height: 100vh;
                background-position: center center;
                top: 0;
                left: 0;
                z-index: 1;
            }
            .h1{
                font-size: 60px;
                color: #e5e5e5;
                text-align: center;
                margin-top: 150px;

            }
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-dark">
  <a class="navbar-brand" href="#" style="padding-left: 0px;"><button class="btn text-light"><h5> VAULT BOARD</h5></button></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">   
    
  </div>
  </nav>
   <div class="container1">
  <div class="overlay">
  <div class="row">
    <div class="col col-lg-6 col-md-6 col-sm-6">
      <h1 class="h1 text-center" style="color:#e5e5e5">Vault Board</h1>
    </div>
    <div class="col col-lg-3 col-md-3 col-sm-4 ">
      <form action="#" method="post" class="form " enctype="multipart/form-data" style="font-size: 1.5em;margin-top: 95px;">
                <div class="form-group">
                  <label for="exampleInputEmail1" style="color:#e5e5e5">Email address</label>
                  <input type="email" name="recemail" class="form-control" id="recemail" aria-describedby="emailHelp" placeholder="Enter email" style="background-color:#b2b2b2">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1" style="color:#e5e5e5">Password</label>
                  <input type="password"  name = "recpassword"class="form-control" id="recpassword" placeholder="Enter Password" style="background-color:#b2b2b2">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword" style="color:#e5e5e5">Confirm Password</label>
                  <input type="password"  name = "recconfpassword"class="form-control" id="recconfpassword" placeholder="Confirm Password" style="background-color:#b2b2b2">
                </div>
                <div class="form-group" style="align-content: center;">
                  <input type="submit" name="recsubmit" class="btn btn-success " >
                <p class="text-center text-light" style="font-size: 1em;"><small>Already Registered? <a href="index_recruiter.php">Login here</a></small> </p>
                </div>
               
            </form>
    </div>
    </div>
  </div>
  </div>
  <?php 
        include "footer.php";
        ?>

</body>
</html>



re