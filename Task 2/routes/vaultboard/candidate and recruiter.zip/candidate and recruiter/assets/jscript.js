
function validateForm() {
  var x = document.getElementById("skill").value;
  if (x == '') {
    alert("Enter atleast one key skill!!");
    return false;
  }
}
function validateFormOne() {
  var x = document.getElementById("skillll").value;
  var y = document.getElementById("currdesg").value;
  var z = document.getElementById("prefloc").value;
   if ((x != '' || y !=''|| z != '') && (x != null || y !=null || z != null)) {
    return true;
  }
  else
  {
    alert("Enter atleast one refining factor to refine search!");
    return false;
  }
}
function validateFormTwo() {
  var x = document.getElementById("skilll").value;
  var y = document.getElementById("currdesg").value;
  var z = document.getElementById("prefloc").value;
  if ((x != '' || y !=''|| z != '') && (x != null || y !=null || z != null)) {
    return true;
  }
  else
  {
    alert("Enter atleast one refining factor to refine search!");
    return false;
  }
}