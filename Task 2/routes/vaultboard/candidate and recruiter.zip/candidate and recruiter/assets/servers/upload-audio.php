<?php
include 'connect.php';
if(isset($_FILES["audio"])){
	$query = "select * from answer";
	$result = $conn->query($query);
	while($row = $result->fetch_assoc()) {
		$id = $row[ans_id];
	}
    // Define a name for the file
    $fileName = "$id+myaudio.webm";
	
    // In this case the current directory of the PHP script
    $folder = 'upload/';
    $audio_path = $folder.$fileName;
    // Move the file to your server
	if(move_uploaded_file($_FILES["audio"]["tmp_name"], $audio_path))
	{
		echo 'uploaded successfully';
		
		saveAudio($audio_path);
	}
}
else if(isset($_FILES["audiovideo"])){
	$query = "select * from answer";
	$result = $conn->query($query);
	while($row = $result->fetch_assoc()) {
		$id = $row[ans_id];
	}
    // Define a name for the file
    $fileName = "$id+myvideo.webm";
	
    // In this case the current directory of the PHP script
    $folder = 'upload/';
    $audio_path = $folder.$fileName;
    // Move the file to your server
	if(move_uploaded_file($_FILES["audiovideo"]["tmp_name"], $audio_path))
	{
		echo 'uploaded successfully';
		
		saveAudio($audio_path);
	}
}
function saveAudio($filename){
	include 'connect.php';
	
	$query = "insert into answer(answername) values('$filename')";
	$result = $conn->query($query);
}
?>