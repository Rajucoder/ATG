<?php
include 'connect.php';
	$query = "select * from answer";
	$result = $conn->query($query);
	while($row = $result->fetch_assoc()) {
	?>
		<video controls>
		<source src="<?php echo $row['answername'];?>" type="audio/webm">
		</source>
		</video>
	<?php
	}	
?>
