<?php
session_start();
   include "../includes/connection.php";
   $id = $_SESSION['recuserid'];

if(strlen($_SESSION['recuserid'])==0)
{
header('location:index_recruiter.php');
}
else{
$recid = $_SESSION['recuserid'];
$_SESSION['recuserid']=$recid;

?>


<!DOCTYPE html>
<html>
<head>
	<title>HOME</title>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>

  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
  <script type="text/javascript" src="assets/bootstrap-tagsinput.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.css">
  	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.js"></script>

  <link rel="stylesheet" type="text/css" href="../assets/styles.css">
  <link rel="stylesheet" type="text/css" href="../assets/bootstrap-tagsinput.css">
   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>  
      <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" integrity="sha384-xrRywqdh3PHs8keKZN+8zzc5TX0GRTLCcmivcbNJWm2rs5C8PRhcEn3czEjhAO9o" crossorigin="anonymous"></script>
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<style type="text/css">
		 .container1{
                background-image: url(../images/home_background.jpg);
                background-repeat: no-repeat;
                padding-top: 0px;
                background-size: cover;
                position: relative;
                width: 100%;
                height: 600px;
            }
             .overlay{
                background: #0000008a;
                width: 100%;
                height: 100%;
                position: absolute;
                top: 0;
                left: 0;
                z-index: 1;
            }
             .site_title{
                position: absolute;
                top: 50%;
               left: 15%;
                -webkit-transform: translateY(-50%);
                -ms-transform: translateY(-50%);
                transform: translateY(-50%);
                z-index: 2;
                font-family: sans-serif;

            }
            .login_setup{
                position: absolute;
               top: 50%;
               left: 70%;
               right: 15%;
                -webkit-transform: translateY(-50%);
                -ms-transform: translateY(-50%);
                transform: translateY(-50%);
                z-index: 2;
                font-family: sans-serif;

            }

            .site_title h1{
                font-size: 60px;
                color: #ab9e9e;
                text-align: center;
                margin: 0;

            }

            .site_title p{
                font-size: 20px;
                color: #ab9e9e;
                text-align: center;
                margin: 0;
                letter-spacing: 6px;
                margin-top: 10px;
            }
            .form{
            	height: 350px;
            	font-size: 1.5em


            }
            .navbar{
              margin:0 !important;
            }
            .active {
              background-color: #FF69B4;
            }

            .navbar-nav > li{
              padding-left:30px;
              padding-right:30px;
            }
            
	</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg  navbar-light bg-dark ">
  <a class="navbar-brand" href="#" style="padding-left: 0px;"><button class="btn text-light" style=" ">VAULT BOARD</button></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color: #FF69B4;">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#"><button class="btn  text-light">Home</button><span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="recbuildprofile/rec_view_profile.php"><button class="btn text-light "> Profile</button></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="searchcandidates/search_candidates.php"><button class="btn text-light">Search Candidates</button></a>
      </li>
     
    </ul>
    <ul class="nav navbar-nav navbar-right">
          <li class="nav-item">
            <form method="get" action="../logout.php"> <button name="reclogout" type="submit" class="btn btn-danger text-light ">Logout</button></form>
          </li>
      </ul>
    
  </div>
</nav>

 <div class="container1">

            <div class="site_title">
                <h1>Vault Board</h1>
                <p>HOME PAGE</p>
                
            </div>
           
            <div class="overlay"></div>
        </div>
        <?php 
        include "../footer.php";
        ?>
</body>
</html>
<?php } ?>