<!doctype html>
<html>
<head>
</head>
<body>
<audio controls>
<source src="<?php echo $_GET['name'];?>" type="audio/webm">
</source>
</audio>
</body>