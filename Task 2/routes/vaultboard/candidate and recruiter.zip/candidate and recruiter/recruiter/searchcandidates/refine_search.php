<?php
session_start();
   include "../../includes/connection.php";
   error_reporting(E_ERROR | E_PARSE);
   

if(strlen($_SESSION['recuserid'])==0)
{
header('location:../../index_recruiter.php');
}
else{
	    if(isset($_POST['refinesubmit'])){
        $passed_array = unserialize($_POST['initialresults']);
        $preferredlocation = $_POST['preferredlocation'];
        $currentdesignation = $_POST['currentdesignation'];
        $excludekeyskills = $_POST['excludekeyskills'];
        $skilarr = array();
        $fincands = array();
        $displayingcand = array();
        $keywords = $_POST['keywordshide'];
        $salaryfrom = $_POST['salaryfromhide'];
        $salaryto = $_POST['salarytohide'];
        $expfrom = $_POST['expfromhide'];
        $expto = $_POST['exptohide'];

        if ($excludekeyskills=='') {
          foreach ($passed_array as $keys)
          {
            $sql = $pdo->prepare("select * from user_basics
              where (Current_designation = :currentdesignation or :currentdesignation='')
              and (current_location = :preferredlocation or :preferredlocation = '')
              and id = :fincands");
            $sql->bindParam(':currentdesignation',$currentdesignation);
            $sql->bindParam(':preferredlocation',$preferredlocation);
            $sql->bindParam(':fincands',$keys);
            $sql->execute();
            $result = $sql->fetchall();
            foreach ($result as $result) {
              $finaluser_id[] = $result['id'];
            }
          }
        }
        else
        {
          $splitting = explode(',', $excludekeyskills);
        foreach ($splitting as $split) 
          {
            $splitexckeyskills[] = trim($split);
          }
        foreach ($splitexckeyskills as $seks)
          {
            //echo $seks;
            $sqli = $pdo->prepare("select id from skills where skill_set_name = :keywords");
            $sqli->bindParam(':keywords',$seks);
            $sqli->execute();
            $resulti = $sqli->fetch(PDO::FETCH_OBJ);
            $skilarr[] = $resulti->id;
          }
        foreach ($skilarr as $skilid)
          {
            foreach($passed_array as $candy)
            {
              $sql = $pdo->prepare("select * from candidate_skills where user_account_id = :user_account_id and skill_id = :skill_id");
              $sql->bindParam(':user_account_id',$candy);
              $sql->bindParam(':skill_id',$skilid);
              $sql->execute();
              $result = $sql->fetchall();
              foreach ($result as $result) {
                $fincands[] = $result['user_account_id'];
              }
            }
          }
          $fincands = array_unique($fincands);
          foreach ($fincands as $fincands)
          {
            $sql = $pdo->prepare("select * from user_basics
              where (Current_designation = :currentdesignation or :currentdesignation='')
              and (current_location = :preferredlocation or :preferredlocation = '')
              and id = :fincands");
            $sql->bindParam(':currentdesignation',$currentdesignation);
            $sql->bindParam(':preferredlocation',$preferredlocation);
            $sql->bindParam(':fincands',$fincands);
            $sql->execute();
            $result = $sql->fetchall();
            foreach ($result as $result) {
              $finaluser_id[] = $result['id'];
            }
          }
        }

    }

	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Search Candidadtes</title>
   
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-tagsinput.css">
      <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-multiselect.css">
      <link rel="stylesheet" type="text/css" href="../../assets/styles.css">
      <link rel="stylesheet" type="text/css" href="../../../assets/bootstrap-tagsinput.css">
      <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-tagsinput.css">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>      
      <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>      
      <script type="text/javascript" src="../../assets/bootstrap-multiselect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
     <script type="text/javascript" src="../../assets/bootstrap-tagsinput.js"></script>    
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
     <script type="text/javascript" src="../../assets/bootstrap-tagsinput.js"></script>
     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.css">
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
       <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/css/bootstrap-tokenfield.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/bootstrap-tokenfield.js"></script>
  <script type="text/javascript" src="../../assets/jscript.js"></script>
          
      <style type="text/css">
      
            .active {
              background-color: #FF69B4;
            }
            .input,.label,.form-control{
             padding-bottom: 0px;
           }
    </style>
	</head>
	<body>
       <nav class="navbar navbar-expand-lg navbar-expand-md navbar-expand-sm navbar-light bg-dark">
      <a class="navbar-brand" href="#" style="padding-left: 0px;"><button class="btn text-light" style=" "> VAULT BOARD</button></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color: #FF69B4;">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="../rec_home.php"><button class="btn  text-light">Home</button><span class="sr-only">(current)</span></a>
          </li>
          
          <li class="nav-item active">
            <a class="nav-link" href="#"><button class="btn text-light">Search Candidates</button></a>
          </li>
             
        </ul>
           <ul class="nav navbar-nav navbar-right">
          
          <li class="nav-item">
            <form method="get" action="../../logout.php"> <button name="logout" type="submit" class="btn btn-danger text-light ">Logout</button></form>
          </li>
        </ul>

        
      </div>
    </nav>
      <div class="row">

        <div class="col col-lg-12 col-md-12 col-sm-12" style="padding-top: 0px;">
            <h2 class="text-center text-secondary">Search For Candidates</h2>
            <div class="card">
              <div class="row">
              <div class="col col-lg-10 col-md-10 col-sm-10">
              <p class="text-secondary text-center">Keywords : <?php echo " ";echo $excludekeyskills;?> || Current Designation : <?php echo " ";echo $currentdesignation; ?> || Current Location : <?php echo " ";echo $preferredlocation;?></p>
            </div> <div class="col col-lg-2 col-md-2 col-sm-2 float-right">
                <button type="button" data-toggle="modal" data-target=".bd-example-modal-lg" class="btn btn-warning">Modify</button>
                <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                    <form style="margin-top: 50px;" name="myForm" action="search_results.php" method="post" enctype="multipart/form-data" class="form-horizontal" onsubmit="return validateForm()">
                      <div class="form-group row">
                          <div class="col col-lg-4 col-md-4 col-sm-12"><label  class="label" for="keywords">Keywords</label></div>
                        <div class="col col-lg-8 col-md-8 col-sm-12"><input type="text" autocomplete="off" id="skill"  class="form-control inputtype"  value="<?php echo $keywords;?>" name="keywords" />
                       </div>
                      </div>
                      <div class="form-group row">
                          <div class="col col-lg-4 col-md-4 col-sm-12"><label  class="label" for="annualsalary">Annual Salary</label></div>
                        <div class="col col-lg-4 col-md-3 col-sm-5"><label class="label" >From Rs /-</label><input type="number" id="totalsalaryfrom" class="form-control bfh-number inputtype" min="0" maxlength="50" name="totalsalaryfrom" value="<?php echo $salaryfrom;?>" />
                        </div><div class="col col-lg-4 col-md-3 col-sm-5"><label class="label" >To Rs/-</label><input type="number" id="totalsalaryto" min="0" class="form-control bfh-number" maxlength="50" name="totalsalaryto" value="<?php echo $salaryto;?>"/></div>
                      </div><br>
                      <div class="form-group row">
                          <div class="col col-lg-4 col-md-4 col-sm-12"><label class="label"  for="experience">Experience </label></div>
                        <div class="col col-lg-4 col-md-3 col-sm-5"><label class="label" >From Yrs</label><input type="number" id="expfrom" class="form-control bfh-number inputtype" min="0" maxlength="50" name="totalexperiencefrom" value="<?php echo $expfrom;?>"/>
                        </div><div class="col col-lg-4 col-md-3 col-sm-5"><label class="label" >To Yrs</label><input type="number" id="expto" min="0" class="form-control bfh-number inputtype" maxlength="50" name="totalexperienceto" value="<?php echo $expto;?>"/></div>
                      </div>
                      <div class="form-group row">
                          <div class="col col-lg-4 col-md-4 col-sm-12"><label  class="label" for="currentlocation">Current Location</label></div>
                        <div class="col col-lg-8 col-md-8 col-sm-12"><input type="text" id="currentlocation" class="form-control inputtype" maxlength="50" autocomplete="off"  name="currentlocation" value="<?php echo $currentlocation;?>"/></div>
                      </div>      
                    <div class="row">
                    <div class="col col-lg-4 col-md-4 col-sm-4"></div>
                    <div class="col col-lg-4 col-md-4 col-sm-4"><input class="btn btn-success btn-rounded" value="Seach for Candidates" name="submit" type="submit" /></div>
                  </div>
                </form>
                  <script src="..\assets\jscript.js"/>


                <script>
                  function validate() {
                    var x = document.forms["search"]["keywords"].value;
                    if (x == "") {
                      alert("Name must be filled out");
                      return false;
                    }
                  }
                  </script>
                  
                <script>
				$(document).ready(function(){
				 
				 $('#skill').tokenfield({
				  autocomplete:{
				   <?php 
				    $sql = $pdo->prepare("select * from skills");
				    $sql->execute();
				    $result = $sql->fetchall();
				    echo "source: [";
				    foreach($result as $res){
				      echo "'";echo $res['skill_set_name'];echo "'";
				      echo ",";
				    }
				    echo "],";
				    ?>
				   delay:100
				  },
				  showAutocompleteOnFocus: false
				 }); 
				});
				</script>
                  </div>
                </div>
              </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    <div class="row">
      <div class="col col-lg-3 col-md-3 col-sm-3 position-fixed mr-auto" style="padding-top: 10px;">
            <form action="#" method="post" onsubmit="return validateFormTwo()" enctype="multipart/form-data" autocomplete="off" >
              <h4 class="text-center text-secondary">Refine Search</h4>
              <div class="form-group">
                <label  class="label" for="Currentdesignation">Current Designation</label>
                <input class="form-control inputtype" id="currdesg"  type="text" name="currentdesignation"  /> 
              </div>
              <div class="form-group">
                <label  class="label" for="excludeKeySkills">Exclude Keyskills</label>
                <input class="form-control inputtype" id="skilll"  type="text" name="excludekeyskills" autocomplete="off" /> 
              </div>
              <div class="form-group">
                <label  class="label" for="preferredLocation">Preferred Location</label>
                <input class="form-control inputtype" id="prefloc"  type="text" name="preferredlocation">
              </div>
              <input type='hidden' name='initialresults' value="<?php echo htmlentities(serialize($finaluser_id)); ?>" />
              <input type="hidden" name="keywordshide" value="<?php echo $keywords;?>"/>
              <input type="hidden" name="salaryfromhide" value="<?php echo $salaryfrom;?>"/>
              <input type="hidden" name="salarytohide" value="<?php echo $salarytoa;?>"/>
              <input type="hidden" name="expfromhide" value="<?php echo $expfrom;?>"/>
              <input type="hidden" name="exptohide" value="<?php echo $expto;?>"/>
              <div class="form-group"><input class="btn btn-rounded btn-success" type="submit" value="Refine Search" name="refinesubmit"/></div>
             </form>  
             <script>
              $(document).ready(function(){
               
               $('#skilll').tokenfield({
                autocomplete:{
                 <?php 
                  $sql = $pdo->prepare("select * from skills");
                  $sql->execute();
                  $result = $sql->fetchall();
                  echo "source: [";
                  foreach($result as $res){
                    echo "'";echo $res['skill_set_name'];echo "'";
                    echo ",";
                  }
                  echo "],";
                  ?>
                 delay:100
                },
                showAutocompleteOnFocus: false
               }); 
              });
              </script>     
        </div>
        
        <div id="candidateview" class="col col-lg-9 col-md-9 col-sm-9 ml-auto candidateview" style=" padding-top: 10px ;overflow-y: scroll; height:450px;">
          <?php
         error_reporting(E_ERROR | E_PARSE);
         for($i=0;$i<sizeof($finaluser_id);$i++) {
          //echo $finaluser_id[$i];
           $sql = $pdo->prepare("select * from user_account where id=:cand_id");
           $sql->bindParam(':cand_id',$finaluser_id[$i]);
         $sql->execute();
         $results = $sql->fetchAll();
         foreach ($results as $result) {
         $userid = $result['id'];
         $sql1 = $pdo->prepare("select * from user_basics where id=:userid");
         $sql1->bindParam(':userid',$userid);
         $sql1->execute();
         $result1 = $sql1->fetch(PDO::FETCH_OBJ);
         ?>
         <div class="container">
         <div class="card-group">
            <div class="card" >
               <div class="card-header">
                                    <div class="row">
                    <div class="col col-lg-4 col-md-4 col-sm-12">
                      <h6 class="card-title text-primary"><?php echo $result['first_name'];echo " ";echo $result['last_name'];?></h6>
                  <div class="row">
                     <p class="card-text" style="height: 1.5em; padding-left: 10px"><span><i class="fas fa-address-card "></i></span><?php echo $result1->total_exp_yrs;echo "Yr ";echo $result1->total_exp_months;echo "M"?></p>
                     <p class="card-text" style="height: 1.5em; padding-left: 10px"><span><i class="fas fa-wallet"></i></span><?php echo $result1->current_salary;echo " p/a ";?></p>
                     <p class="card-text" style="height: 1.5em; padding-left: 10px"><span><i class="fas fa-map-marker-alt"></i></span><?php echo $result1->current_location;?></p>
                  </div> 
                    </div>
                    <div class="col col-lg-6 col-md-6 col-sm-12 ">
                      <p class="text-secondary"><i class="fas fa-phone-square"></i>Contact: <?php echo $result['mobile_number'];
                     $phnverify=$result['mobile_verified'];
                     if ($phnverify=='Y') {?>
                     <i class="fas fa-check-circle"></i>
                     <?php }else{ ?>
                     <i class="fas fa-times-circle"></i>
                     <?php }
                        ?></p>
                  <p class="text-secondary"><i class="fas fa-envelope"></i>Email: <?php echo $result['email'];
                     $emailverify=$result['email_verified'];
                     if ($emailverify=='Y') {?>
                     <i class="fas fa-check-circle"></i>
                     <?php }else{ ?>
                     <i class="fas fa-times-circle"></i>
                     <?php }?>
                  </p>
                    </div>
                    <div class="col col-lg-2 col-md-2 col-sm-12 float-right">
                      <button id="show<?php echo $finaluser_id[$i];?>" class="btn btn-primary btn-rounded float-right" > View Resume</button>
                    </div>
                  </div>
               </div>
               <div class="card-body" style="font-size: 0.85em;">
                  <div class="row">
                     <div class="col col-lg-8 col-md-8 col-sm-8">
                  <div class="row">
                    <div class="col col-lg-3 col-md-4 col-sm-6"><h5 class="card-title text-primary ">Current</h5></div>
                    <div class="col col-lg-9 col-md-8 col-sm-10">
                       <p ><?php echo $result1->Current_designation;echo " at ";echo $result1->Current_company;echo ", since ";echo $result1->Current_since; ?></p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col col-lg-3 col-md-4 col-sm-6"><h5 class="card-title text-primary ">Education</h5></div>
                    <div class="col col-lg-9 col-md-8 col-sm-10">
                       <?php  $sql2 = $pdo->prepare("select * from education_detail where user_account_id=:userid");
                              $sql2->bindParam(':userid',$userid);
                              $sql2->execute();
                              $results2 = $sql2->fetchall();?>
                              <?php foreach ($results2 as $result2) {
                                 echo '<p class="card-text">'; echo "--";echo $result2['degree_name'];echo " ";echo $result2['major'];echo " at ";echo $result2['university'];echo " with CGPA ";echo $result2['cgpa'];echo "/";echo $result2['cgpa_max'];?></p><?php  }?> 

                    </div>
                  </div>
                  <div class="row">
                    <div class="col col-lg-3 col-md-4 col-sm-6"><h5 class="card-title text-primary ">Experience</h5></div>
                    <div class="col col-lg-9 col-md-8 col-sm-10">
                       <?php $sql3 = $pdo->prepare("select * from experience_detail where user_account_id=:userid");
                              $sql3->bindParam(':userid',$userid);
                              $sql3->execute();
                              $results3 = $sql3->fetchall();?>
                              <?php foreach ($results3 as $result3) {
                                echo '<p  >';echo "--";echo "Worked as ";echo $result3['job_title'];echo " at ";echo $result3['company_name'];echo ", ";echo $result3['job_location_city'];echo ", from ";echo $result3['start_date'];echo " to ";echo $result3['end_date'];?></p>
                              <p >Role :<?php echo $result3['role'];echo '</p>';}?>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col col-lg-3 col-md-4 col-sm-6"><h5 class="card-title text-primary ">Key Skills</h5></div>
                    <div class="col col-lg-9 col-md-8 col-sm-10">
                       <?php $sql4 = $pdo->prepare("select * from candidate_skills where user_account_id=:userid");
                              $sql4->bindParam(':userid',$userid);
                              $sql4->execute();
                              $results4 = $sql4->fetchall();
                              echo '<p class="text-secondary" >';
                              foreach ($results4 as $result4) {
                              $res4= $result4['skill_id'];
                              $sql5 = $pdo->prepare("select * from skills where id=:id");
                              $sql5->bindParam(':id',$res4);
                              $sql5->execute();
                              $results5 = $sql5->fetchall();
                              foreach ($results5 as $result5) {
                              echo $result5['skill_set_name'];echo ", ";}}echo '</p>';?>
                    </div>
                  </div>  </div> 
                  <div class="col col-lg-4 col-md-4 col-sm-4">
<?php 
              //$id = $_SESSION['userid'];
              $con=mysqli_connect("localhost","root","","vault");
                $res=mysqli_query($con,"select * from user_basics where id= '$finaluser_id[$i]'");
               while($row=mysqli_fetch_array($res))
               {
               echo '<img src="data:image/jpeg;base64,'.base64_encode($row['user_image'] ).'" height="200" width="200"/>';
               }
                ?><br><br>
                   <p class="text-primary"><?php echo $result1->Profile_summary;?></p>
                  </div> 
                  </div>                 
               </div>
                <div class="card-footer">
                  <div class="showresume<?php echo $finaluser_id[$i]?>">
                    <?php 
                      $sql = $pdo->prepare("select * from user_basics where id = :id");
                      $sql->bindParam(':id',$finaluser_id[$i]);
                      $sql->execute();
                      $p = $sql->fetchall();
                      foreach($p as $pgi){?>
                        <button id = "close<?php echo $finaluser_id[$i]?>" class="btn btn-danger">X</button>
                      <embed src="../../uploads/<?php echo $pgi['resume'] ?>"width ="100%" height ="450px" ></embed><?php } ?>
                       <script type="text/javascript">
                            $('.showresume<?php echo $finaluser_id[$i]?>').hide();
                    $('#show<?php echo $finaluser_id[$i]?>').on('click',function(){$('.showresume<?php echo $finaluser_id[$i]?>').show();})
                      $('#close<?php echo $finaluser_id[$i]?>').on('click',function(){$('.showresume<?php echo $finaluser_id[$i]?>').hide();})
                  </script>
                  </div>
               </div>
               
              </div>
           
         </div>
      </div>
      <br><br>
      <br><?php }}?>
        </div>
    </div>
      
  
		<script type="text/javascript">

$(document).ready(function(){
 
 $('#currentlocation').typeahead({
  source: function(query, result)
  {
   $.ajax({
    url:"fetch1.php",
    method:"POST",
    data:{query:query},
    dataType:"json",
    success:function(data)
    {
     result($.map(data, function(item){
      return item;
     }));
    }
   })
  }
 });
 
});
</script>
  <script src="..\assets\jscript.js"/>
	</body>
	</html>
	<?php }?>