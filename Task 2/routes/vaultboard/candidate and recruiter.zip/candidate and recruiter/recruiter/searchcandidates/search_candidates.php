<?php
session_start();
   include "../../includes/connection.php";

if(strlen($_SESSION['recuserid'])==0)
{
header('location:../../index_recruiter.php');
}
else{
	    
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>Search Candidadtes</title>
   
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-tagsinput.css">
      <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-multiselect.css">
      <link rel="stylesheet" type="text/css" href="../../assets/styles.css">
      <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-tagsinput.css">
      <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-tagsinput.css">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>      
      <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>      
      <script type="text/javascript" src="../../assets/bootstrap-multiselect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
     <script type="text/javascript" src="../../assets/bootstrap-tagsinput.js"></script>    
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
     <script type="text/javascript" src="../../assets/bootstrap-tagsinput.js"></script>
     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.css">
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/css/bootstrap-tokenfield.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-tokenfield/0.12.0/bootstrap-tokenfield.js"></script>
  <script type="text/javascript" src="../../assets/jscript.js"></script>
          
      <style type="text/css">
      
            .active {
              background-color: #FF69B4;
            }
    </style>
	</head>
	<body>
    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-expand-sm navbar-light bg-dark">
      <a class="navbar-brand" href="#" style="padding-left: 0px;"><button class="btn text-light" style=" "> VAULT BOARD</button></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color: #FF69B4;">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item">
            <a class="nav-link" href="../rec_home.php"><button class="btn  text-light">Home</button><span class="sr-only">(current)</span></a>
          </li>
          
          <li class="nav-item active">
            <a class="nav-link" href="#"><button class="btn text-light">Search Candidates</button></a>
          </li>
             
        </ul>
           <ul class="nav navbar-nav navbar-right">
          
          <li class="nav-item">
            <form method="get" action="../../logout.php"> <button name="logout" type="submit" class="btn btn-danger text-light ">Logout</button></form>
          </li>
        </ul>

        
      </div>
    </nav>
    <div class="container">
      <h5 class="text-center">Search For Candidates</h5>
           <form style="margin-top: 50px;" action="search_results.php" method="post" autocomplete="off" name="myForm" enctype="multipart/form-data"  onsubmit="return validateForm()">
            <div class="form-group row">
                <div class="col col-lg-4 col-md-4 col-sm-12"><label  class="label" for="keywords">Keywords</label></div>
              <div class="col col-lg-8 col-md-8 col-sm-12"><input type="text"  id="skill"  class="form-control inputtype" name="keywords" />
             </div>
            </div>
            <div class="form-group row">
                <div class="col col-lg-4 col-md-4 col-sm-12"><label  class="label" for="annualsalary">Annual Salary</label></div>
              <div class="col col-lg-4 col-md-3 col-sm-5"><label  class="label" >From Rs /-</label><input type="number" id="totalsalaryfrom" class="form-control bfh-number inputtype" min="0" maxlength="50" name="totalsalaryfrom"/>
              </div><div class="col col-lg-4 col-md-3 col-sm-5"><label class="label" >To Rs/-</label><input type="number" id="totalsalaryto" min="0" class="form-control bfh-number inputtype" maxlength="50" name="totalsalaryto"/></div>
            </div><br>
            <div class="form-group row">
                <div class="col col-lg-4 col-md-4 col-sm-12"><label class="label"  for="experience">Experience </label></div>
              <div class="col col-lg-4 col-md-3 col-sm-5"><label class="label" >From Yrs</label><input type="number" id="expfrom" class="form-control bfh-number inputtype" min="0" maxlength="50" name="totalexperiencefrom"/>
              </div><div class="col col-lg-4 col-md-3 col-sm-5"><label class="label" >To Yrs</label><input type="number" id="expto" min="0" class="form-control bfh-number inputtype" maxlength="50" name="totalexperienceto"/></div>
            </div>
            <div class="form-group row">
                <div class="col col-lg-4 col-md-4 col-sm-12"><label  class="label" for="currentlocation">Current Location</label></div>
              <div class="col col-lg-8 col-md-8 col-sm-12"><input type="text" id="currentlocation" class="form-control inputtype" maxlength="50" autocomplete="off"  name="currentlocation"></div>
            </div>      
          <div class="row">
          <div class="col col-lg-4 col-md-4 col-sm-4"></div>
          <div class="col col-lg-4 col-md-4 col-sm-4"><input class="btn btn-success btn-rounded inputtype" value="Seach for Candidates" name="submit" type="submit" /></div>
        </div>
      </form>
    </div>
    <?php
         error_reporting(E_ERROR | E_PARSE);
         for($i=0;$i<sizeof($finaluser_id);$i++) {
           $sql = $pdo->prepare("select * from user_account where id=:cand_id");
           $sql->bindParam(':cand_id',$finaluser_id[$i]);
         $sql->execute();
         $results = $sql->fetchAll();
         foreach ($results as $result) {
         $userid = $result['id'];
         $sql1 = $pdo->prepare("select * from user_basics where id=:userid");
         $sql1->bindParam(':userid',$userid);
         $sql1->execute();
         $result1 = $sql1->fetch(PDO::FETCH_OBJ);
         ?>
      <div class="container" >
         <div class="card-group">
            <div class="card" >
               <div class="card-header">
                  <h6 class="card-title text-primary"><?php echo $result['first_name'];echo " ";echo $result['last_name'];?></h6>
                  <div class="row">
                     <p class="card-text" style="height: 1.5em; padding-left: 10px"><span><i class="fas fa-address-card "></i></span><?php echo $result1->total_exp_yrs;echo "Yr ";echo $result1->total_exp_months;echo "M"?></p>
                     <p class="card-text" style="height: 1.5em; padding-left: 10px"><span><i class="fas fa-wallet"></i></span><?php echo $result1->current_salary;echo " p/a ";?></p>
                     <p class="card-text" style="height: 1.5em; padding-left: 10px"><span><i class="fas fa-map-marker-alt"></i></span><?php echo $result1->current_location;?></p>
                  </div> 
               </div>
               <div class="card-body" style="font-size: 0.85em;">
                  <div class="row">
                     <div class="col col-lg-8 col-md-8 col-sm-8">
                  <div class="row">
                    <div class="col col-lg-3 col-md-4 col-sm-6"><h5 class="card-title text-primary ">Current</h5></div>
                    <div class="col col-lg-9 col-md-8 col-sm-10">
                       <p ><?php echo $result1->Current_designation;echo " at ";echo $result1->Current_company;echo ", since ";echo $result1->Current_since; ?></p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col col-lg-3 col-md-4 col-sm-6"><h5 class="card-title text-primary ">Education</h5></div>
                    <div class="col col-lg-9 col-md-8 col-sm-10">
                       <?php  $sql2 = $pdo->prepare("select * from education_detail where user_account_id=:userid");
                              $sql2->bindParam(':userid',$userid);
                              $sql2->execute();
                              $results2 = $sql2->fetchall();?>
                              <?php foreach ($results2 as $result2) {
                                 echo '<p class="card-text">'; echo "--";echo $result2['degree_name'];echo " ";echo $result2['major'];echo " at ";echo $result2['university'];echo " with CGPA ";echo $result2['cgpa'];echo "/";echo $result2['cgpa_max'];?></p><?php  }?> 

                    </div>
                  </div>
                  <div class="row">
                    <div class="col col-lg-3 col-md-4 col-sm-6"><h5 class="card-title text-primary ">Experience</h5></div>
                    <div class="col col-lg-9 col-md-8 col-sm-10">
                       <?php $sql3 = $pdo->prepare("select * from experience_detail where user_account_id=:userid");
                              $sql3->bindParam(':userid',$userid);
                              $sql3->execute();
                              $results3 = $sql3->fetchall();?>
                              <?php foreach ($results3 as $result3) {
                                echo '<p  >';echo "--";echo "Worked as ";echo $result3['job_title'];echo " at ";echo $result3['company_name'];echo ", ";echo $result3['job_location_city'];echo ", from ";echo $result3['start_date'];echo " to ";echo $result3['end_date'];?></p>
                              <p ><label class="label" >Role :</label><?php echo $result3['role'];echo '</p>';}?>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col col-lg-3 col-md-4 col-sm-6"><h5 class="card-title text-primary ">Key Skills</h5></div>
                    <div class="col col-lg-9 col-md-8 col-sm-10">
                       <?php $sql4 = $pdo->prepare("select * from candidate_skills where user_account_id=:userid");
                              $sql4->bindParam(':userid',$userid);
                              $sql4->execute();
                              $results4 = $sql4->fetchall();
                              echo '<p class="text-secondary" >';
                              foreach ($results4 as $result4) {
                              $res4= $result4['skill_id'];
                              $sql5 = $pdo->prepare("select * from skills where id=:id");
                              $sql5->bindParam(':id',$res4);
                              $sql5->execute();
                              $results5 = $sql5->fetchall();
                              foreach ($results5 as $result5) {
                              echo $result5['skill_set_name'];echo ", ";}}echo '</p>';?>
                    </div>
                  </div>  </div> 
                  <div class="col col-lg-4 col-md-4 col-sm-4 col-xs-4">
                    <?php
                  $row = $sql1->fetch(PDO::FETCH_ASSOC);
                  #header("Content-type: image/png");
                   #print $row['user_image'];
                  echo '<img class="img img-rounded" src="data:image/*;base64,'.base64_encode($row['user_image'] ).'" height="150" width="150"/>';
                   ?><br>
                   <p class="text-primary"><?php echo $result1->Profile_summary;?></p>
                  </div> 
                  </div>                 
               </div>
               <div class="card-footer text-secondary">
                  <div class="row">
                    <div class="col col-lg-6 col-md-6 col-sm-8"><p class="text-secondary"><i class="fas fa-phone-square"></i>Contact: <?php echo $result['mobile_number'];
                     $phnverify=$result['mobile_verified'];
                     if ($phnverify=='Y') {?>
                     <i class="fas fa-check-circle"></i>
                     <?php }else{ ?>
                     <i class="fas fa-times-circle"></i>
                     <?php }
                        ?></p>
                  <p class="text-secondary"><i class="fas fa-envelope"></i>Email: <?php echo $result['email'];
                     $emailverify=$result['email_verified'];
                     if ($emailverify=='Y') {?>
                     <i class="fas fa-check-circle"></i>
                     <?php }else{ ?>
                     <i class="fas fa-times-circle"></i>
                     <?php }?>
                  </p>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-4">
                  <div class="col-lg-6 col-md-6 col-sm-4 float-right">
                      <button class="btn btn-rounded btn-warning">View Resume</button>
                  </div>
                </div>
                  </div>
                  </div>
              </div>
           
         </div>
      </div>
      <br><br>
      <br><?php }}?>
  
	<script>
$(document).ready(function(){
 
 $('#skill').tokenfield({
  autocomplete:{
   <?php 
    $sql = $pdo->prepare("select * from skills");
    $sql->execute();
    $result = $sql->fetchall();
    echo "source: [";
    foreach($result as $res){
      echo "'";echo $res['skill_set_name'];echo "'";
      echo ",";
    }
    echo "],";
    ?>
   delay:100
  },
  showAutocompleteOnFocus: true
 }); 
});
</script>
		<script type="text/javascript">

$(document).ready(function(){
 
 $('#currentlocation').typeahead({
  source: function(query, result)
  {
   $.ajax({
    url:"../fetch1.php",
    method:"POST",
    data:{query:query},
    dataType:"json",
    success:function(data)
    {
     result($.map(data, function(item){
      return item;
     }));
    }
   })
  }
 });
 
});
</script>
	</body>
	</html>
	<?php }?>