<?php
session_start();
include "../../includes/connection.php";
if(strlen($_SESSION['recuserid'])==0)
{
header('location:../../index_recruiter.php');
}
else{

?>
<!DOCTYPE html>
<html>
  <head>
    <title>Basic Profile
    </title>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-tagsinput.css">
    <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-multiselect.css">
    <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-tagsinput.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js">
    </script>  
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js">
    </script>    	
    <script type="text/javascript" src="../../assets/bootstrap-multiselect.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js">
    </script>
    <script type="text/javascript" src="../../assets/bootstrap-tagsinput.js">
    </script>
    <style type="text/css">
     .navbar li.active > a {
                background-color: #FF69B4;
            }
      .navbar-nav > li{
        padding-left:30px;
        padding-right:30px;
      }
    </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg  navbar-light bg-dark ">
      <a class="navbar-brand" href="#" style="">
        <button class="btn text-light" style=" ">
          <h5> VAULT BOARD
          </h5>
        </button>
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color: #FF69B4;">
        <span class="navbar-toggler-icon">
        </span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item ">
            <a class="nav-link" href="../rec_home.php">
              <button class="btn  text-light">Home
              </button>
              <span class="sr-only">(current)
              </span>
            </a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="#">
              <button class="btn  text-light">Build Profile
              </button>
              <span class="sr-only">(current)
              </span>
            </a>
          </li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li class="nav-item">
            <form method="get" action="../../logout.php"> 
              <button name="reclogout" type="submit" class="btn btn-danger text-light ">Logout
              </button>
            </form>
          </li>
        </ul>
      </div>
    </nav>

<button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">build Profile</button>

<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <section id="tabs">
  <div class="container">
    <div class="row">
      <div class="col col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
        <nav>
          <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
            <a class="nav-item nav-link active" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="true">Profile</a>
            <a class="nav-item nav-link" id="nav-education-tab" data-toggle="tab" href="#nav-education" role="tab" aria-controls="nav-education" aria-selected="false">Company Details</a>
            <a class="nav-item nav-link" id="nav-experience-tab" data-toggle="tab" href="#nav-experience" role="tab" aria-controls="nav-experience" aria-selected="false"></a>
          </div>
        </nav>
        <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
          <div class="tab-pane fade show active" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
            <div class="container">
            <form style="margin-top: 50px;" action="rec_store_profile.php" method="post" enctype="multipart/form-data">
              <div class="row ">
                  <div class="form-group">
                    <label class="label" for="imagename">Profile Picture
                    </label>
                    <div class="file-field">
                      <div class="mb-4">
                        <img src="../images/user.png" height="75px" width="75px" class="rounded-circle"
                             >
                      </div>
                      <div class="d-flex justify-content-center">
                        <div class="btn btn-mdb-color btn-rounded float-left">
                          <input class="inputtype" type="file" required="required" name="image" id="image" accept="image/*"/>
                        </div>
                      </div>
                    </div>
                  </div>
              </div>
              <div class="row">
                <div class="col col-lg-8 col-md-12 col-sm-12">
                  <div class="form-group">
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <label class="label" for="firstname">First Name
                      </label>
                    </div>
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <input type="text" id="frstname" class="form-control inputtype" required="required" maxlength="50" name="firstname"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <label  class="label" for="lastname">Last Name
                      </label>
                    </div>
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <input type="text" id="lastname" required="required" class="form-control inputtype" maxlength="50" name="lastname"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <label class="label"  for="mobile">Mobile Number
                      </label>
                      <input type="number"  id="mobile" required="required" class="form-control inputtype" name="mobile"/>
                    </div>
                  </div>
                  <br>
                  
                </div>

        </div>

      </div>
        <div class="form-group">
         <div class="row">
            <div class="col col-lg-4 col-md-4 col-sm-4">
            </div>
            <div class="col col-lg-4 col-md-4 col-sm-4">
              <button class="btn btn-success btn-rounded"name="recpersonalsubmit" type="submit">Save
              </button>
            </div>
          </div>
        </div>
        </form>
   </div>
           <div class="tab-pane fade show active" id="nav-education" role="tabpanel" aria-labelledby="nav-education-tab">
            <div class="container">
            <form style="margin-top: 50px;" action="rec_store_profile.php" method="post" enctype="multipart/form-data">
              <div class="row ">
                  <div class="form-group">
                    <label class="label" for="imagename">Company Picture
                    </label>
                    <div class="file-field">
                      <div class="mb-4">
                        <img src="../../images/building.png" height="75px" width="75px" class="img img-responsive"
                             >
                      </div>
                      <div class="d-flex justify-content-center">
                        <div class="btn btn-mdb-color btn-rounded float-left">
                          <input class="inputtype" type="file" required="required" name="image" id="image" accept="image/*"/>
                        </div>
                      </div>
                    </div>
                  </div>
              </div>
              <div class="row">
                <div class="col col-lg-8 col-md-12 col-sm-12">
                  <div class="form-group">
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <label class="label" for="firstname">Company Name
                      </label>
                    </div>
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <input type="text" id="frstname" class="form-control inputtype" required="required" maxlength="50" name="firstname"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <label  class="label" for="services">Company Product Services
                      </label>
                    </div>
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <input type="text" id="companyservices" required="required" class="form-control inputtype" maxlength="50" name="companyservices"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <label  class="label" for="stream">Business Stream
                      </label>
                    </div>
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <input type="text" id="businessstream" required="required" class="form-control inputtype" maxlength="50" name="businessstream"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <label  class="label" for="website">Company Website
                      </label>
                    </div>
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <input type="text" id="companywebsite" required="required" class="form-control inputtype" maxlength="50" name="companywebsite"/>
                    </div>
                  </div>
                  <br>
                  <div class="form-group">
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <label  class="label" for="details">Company Details
                      </label>
                    </div>
                    <div class="col col-lg-12 col-md-12 col-sm-12">
                      <input type="text" id="companydetails" required="required" class="form-control inputtype" maxlength="50" name="companydetails"/>
                    </div>
                  </div>
                  
                </div>

        </div>

      </div>
        <div class="form-group">
         <div class="row">
            <div class="col col-lg-4 col-md-4 col-sm-4">
            </div>
            <div class="col col-lg-4 col-md-4 col-sm-4">
              <button class="btn btn-success btn-rounded" name="recpersonalsubmit" type="submit">Save
              </button>
            </div>
          </div>
        </div>
        </form>
   </div>
 

        </div>
      
      </div>
    </div>
  </div>
</section>
<!-- ./Tabs -->
    </div>
  </div>
</div>


    
<script type="text/javascript">
  $(document).ready(function(){
    $('#skills').multiselect();
  }
                   );
</script>	
        
</body>
</html>
<?php }?>
