<html>
<head>

<meta charset="utf-8">

<link href="bootstrap.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/simple-sidebar.css" rel="stylesheet"> 
<link href="../../assets/css/simpleGridTemplate.css" rel="stylesheet" type="text/css">
<link href="../../assets../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/Animate.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="../../assets/css/Animate.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/animate.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Kodchasan" rel="stylesheet">

<style>
table {
    border-collapse: separate;
    border-spacing: 1em;
}
</style>
</head>

<body>
	 <nav class="navbar navbar-expand-lg navbar-light fixed-top bg-dark border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Menu</button>

         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color: #FF69B4;">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
           <li class="nav-item ">
           <a class="nav-link" href="../rec_home.php"><button class="btn  text-light">Home</button><span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../recbuildprofile/rec_view_profile.php"><button class="btn  text-light">Profile</button></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="../searchcandidates/search_candidates.php"><button class="btn  text-light">Search Jobs</button><span class="sr-only">(current)</span></a>
          </li>
          
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
          
          <li class="nav-item">
            <form method="get" action="../../logout.php"> <button name="logout" type="submit" class="btn btn-danger text-light ">Logout</button></form>
          </li>
        </ul>

      </div>

        
      </nav>
	<br>

<div class="container">
<form method="post" action="">

	<div class="row">
	<div class = "card">
		<table>
		<td>
			<input type="text" name="name" placeholder="Search Job" class = "form-control"/>
		
		</td>
		<td>
			<input type="text" placeholder="Location" class = "form-control"/>
		</td>
		<td>
			<input type="text" placeholder="Comapany" class = "form-control"/>
		</td>
		<td>
			Experience:
		</td>
		<td> <input type="text" placeholder="Experience" class = "form-control"/></td>
		<td>
                <button type="submit" name="submitPost" class = "btn btn-primary" class="btnContact pull-right" >Search Job</button>
        </td>
		</table>
		</form>
	</div>
	</div>
</div>
</form>
<?php
include '../../includes/connect.php';
if(isset($_POST['submitPost'])){
	$search = $_POST['name'];
	$sql = "SELECT name,place,date FROM post where name LIKE '%$search%'";
    $result = $conn->query($sql);
?>
<table class="table">
  <thead>
    <tr>
      <th scope="col">Job</th>
      <th scope="col">Place</th>
	  <th scope="col">Date</th>
    </tr>
  </thead>
  <?php
    while($row = $result->fetch_assoc()) {
	?>
	<tbody>
	<tr>
	   <td><?php echo " ".$row["name"]." ";?></td>
	   <td><?php echo " ".$row["place"]." ";?></td>
	   <td><?php echo " ".$row["date"]." ";?></td>
	   
        </tr></tbody>
		<?php
    }
}
else{
$sql = "SELECT name,place,date FROM post";
$result = $conn->query($sql);
?>
<table class="table">
  <thead>
    <tr>
      <th scope="col">Job</th>
      <th scope="col">Place</th>
	  <th scope="col">Date</th>
    </tr>
  </thead>
  <?php
    while($row = $result->fetch_assoc()) {
	?>
	<tbody>
	<tr>
	   <td><?php echo " ".$row["name"]." ";?></td>
	   <td><?php echo " ".$row["place"]." ";?></td>
	   <td><?php echo " ".$row["date"]." ";?></td>
	   <form method="post" action="view.php">
        </tr></tbody>
		<?php
    }
}
?> 
</div>
</body>
</html>