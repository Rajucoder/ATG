<?php
session_start();
include "../../includes/connection.php";
if(strlen($_SESSION['recuserid'])==0)
{
header('location:../../index.php');
}
else{
if(isset($_POST['recpersonalsubmit'])){
$recid = $_SESSION['recuserid'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$mobile=$_POST['mobile'];
$user_type_id=2;
$is_active = "N";
$email_notification_active = "N";
$stmt=$pdo->prepare("update recruiter_basic set id=:id,user_type_id=:user_type_id,first_name=:first_name,last_name=:last_name,is_active=:is_active,contact_number=:contact_number where id = :id");
$stmt->bindParam(':id', $id);
$stmt->bindParam(':user_type_id', $user_type_id);
$stmt->bindParam(':first_name', $firstname);
$stmt->bindParam(':last_name', $lastname);
$stmt->bindParam(':is_active', $is_active);
$stmt->bindParam(':contact_number', $mobile);
$stmt->execute();
$con=mysqli_connect("localhost","root","","vault");
$proimage = addslashes(file_get_contents($_FILES['image']['tmp_name']));
$query = "update recruiter_basic set user_image='$proimage' where id = $recid";  
mysqli_query($con, $query); 
$_SESSION['recuserid']=$recid;
echo "<script>document.location = 'rec_view_profile.php';</script>";
}
if(isset($_POST['educationsubmit'])){
$education=$_POST['education'];
$major=$_POST['major'];
$university=$_POST['university'];
$startdate=$_POST['startdate'];
$enddate=$_POST['enddate'];
$cgpa=$_POST['cgpa'];
$cgpamax=$_POST['cgpamax'];
$id = $_SESSION['userid'];
$percentage=$_POST['percentage'];
$stmt=$pdo->prepare("insert INTO education_detail(user_account_id,degree_name,major,university,starting_date,completion_date,percentage,cgpa,cgpa_max) VALUES (:id,:degree_name,:major,:university,:starting_date,:completion_date,:percentage,:cgpa,:cgpa_max)");
$stmt->bindParam(':id', $id);
$stmt->bindParam(':degree_name', $education);
$stmt->bindParam(':major', $major);
$stmt->bindParam(':university',$university);
$stmt->bindParam(':starting_date',$startdate);
$stmt->bindParam(':completion_date',$enddate);
$stmt->bindParam(':percentage',$percentage);
$stmt->bindParam(':cgpa',$cgpa);
$stmt->bindParam(':cgpa_max',$cgpamax);
$stmt->execute();
$_SESSION['userid']=$id;
echo "<script type='text/javascript'>
alert('details filled'); </script>";
echo "<script>document.location = '';</script>";

}
if(isset($_POST['experiencesubmit'])){
$jobtitle=$_POST['jobtitle'];
$companyname=$_POST['companyname'];
$is_currently=$_POST['is_currently'];
if ($is_currently=='yes') {
$is_currently = 'Y';
}elseif ($is_currently=='no') {
$is_currently = 'N';
}
$startdate=$_POST['startdate'];
$enddate=$_POST['enddate'];
$city=$_POST['city'];
$state=$_POST['state'];
$country=$_POST['country'];
$role=$_POST['role'];
$id = $_SESSION['userid'];
$job_type_id=1;
$stmt=$pdo->prepare("insert INTO experience_detail(user_account_id,is_current_job,start_date,end_date,job_title,company_name,job_location_city,job_location_state,job_location_country,role,job_type_id) VALUES (:id,:is_current_job,:start_date,:end_date,:job_title,:company_name,:job_location_city,:job_location_state,:job_location_country,:role,:job_type_id)");
$stmt->bindParam(':id', $id);
$stmt->bindParam(':is_current_job', $is_currently);
$stmt->bindParam(':start_date', $startdate);
$stmt->bindParam(':end_date',$enddate);
$stmt->bindParam(':job_title',$jobtitle);
$stmt->bindParam(':company_name',$companyname);
$stmt->bindParam(':job_location_city',$city);
$stmt->bindParam(':job_location_state',$state);
$stmt->bindParam(':job_location_country',$country);
$stmt->bindParam(':role',$role);
$stmt->bindParam(':job_type_id',$job_type_id);
$stmt->execute();
$_SESSION['userid']=$id;
echo "<script type='text/javascript'>
alert('details filled');</script>";
echo "<script>document.location = '';</script>";

}
}?>
