<!DOCTYPE html>
<html>
<head>
<title>VB</title>
<link href="bootstrap.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<?php
	session_start();
	include '../../includes/connect.php';
	$jobid = $_SESSION["job_id"];
	$question=$_POST['question'];
	echo $jobid;
	echo "<br>";
	echo $question;
	if($_SERVER['REQUEST_METHOD'] == 'POST'){
		$query = "UPDATE post SET question='$question' WHERE job_id='$jobid'";
		$result=$conn->query($query);
		if(isset($_POST['question']) == "Yes"){

			header("Location: screening_test_v1.php"); 
		}
	else{
        header("Location: rec_view_profile.php"); 
	}
	}
?>
<body>
	<div class="box">
	<h3>Do you want to add screening question ?</h3>
	<form method="post">
	<label>
		<input type="submit" name="question" value="Yes" onChange="this.form.submit()">
		<span class="yes">Yes</span>
	</label>
	
	<label>
		<input type="submit" name="question" value = "No" onChange="this.form.submit()">
		<span class="yes">No</span>
	</label>
	</form>
</body>
</html>