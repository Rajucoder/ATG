<?php
session_start();
include '../../includes/connect.php';
header('location:want_question.php');
  	
            $name= $_POST['name'];
            $category=$_POST['category'];
            $minexp=$_POST['minexp'];
            $salary=$_POST['salary'];
            $industry=$_POST['industry'];
            $desc=$_POST['desc'];
            $role=$_POST['role'];
            $place=$_POST['place'];
            
			
          
    $sql = "INSERT INTO `post` (`name`, `category`, `minexp`, `desc`, `salary`, `industry`, `role`, `place`) VALUES ('$name', '$category', '$minexp', '$desc', '$salary', '$industry', '$role', '$place')";
	$result1  = $conn->query($sql);
	$query = "select job_id from post where name = '$name'";
	$result2 = $conn->query($query);
	while($row = $result2->fetch_assoc()) {
	$_SESSION['job_id'] = $row['job_id'];
	}
	?>
	