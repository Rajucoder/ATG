<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">

  <!-- Bootstrap core CSS -->
  <link href="../../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<!--<link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">-->
  <!-- Custom styles for this template -->
  <link href="../../assets/css/simple-sidebar.css" rel="stylesheet">

</head>

<body>

  <div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Vaultboard</div>
      <div class="list-group list-group-flush">
        <a href="../rec_home.php" class="list-group-item list-group-item-action bg-light">Home</a>
        <a href="#" class="list-group-item list-group-item-action bg-light">My Profile</a>
        <a href="#" class="list-group-item list-group-item-action bg-light">My Posted Job</a>
        <a href="../searchcandidates/search_candidates.php" class="list-group-item list-group-item-action bg-light">Search Candidate</a>
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light bg-dark border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Menu</button>

       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color: #FF69B4;">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
           <li class="nav-item ">
           <a class="nav-link" href="../rec_home.php"><button class="btn  text-light">Home</button><span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"><button class="btn  text-light">Profile</button></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="../searchcandidates/search_candidates.php"><button class="btn  text-light">Search Candidates</button><span class="sr-only">(current)</span></a>
          </li>
          
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
          
          <li class="nav-item">
            <form method="get" action="../../logout.php"> <button name="logout" type="submit" class="btn btn-danger text-light ">Logout</button></form>
          </li>
        </ul>

      </div>

        
      </nav>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "post_job";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
	$var = 1;
    // output data of each row
     if(isset($var)) { 
        $name=  "vaultboadcxzrd";
          $email =  "vaultboard@gmail.com";
}
?>
      <div class="container-fluid">
        <div class="col-md-8">
                            <img src="../../images/vaultboardicon.jpg" class="img-circle img-responsive" width="200" style="margin: 20%; box-shadow: 0px 0px 20px #1e1e1e;">
                            <h4>User Name</h4>
                            <h3><?php echo $name; ?></h3>
                             <h4>Email</h4>
                            <h3><?php echo $email; ?></h3>
							<button type = "submit" class="btn btn-danger btn-block">Update Profile</button><br><br>
							<button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#myModal">Post Job</button><br><br>
							<a href="jobsearch.php"><button type="button" class="btn btn-danger btn-block">View</button></a><br><br>
	<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
	  <div class="container" >
            <form method="post" action="store.php">	
                <h3>Post a JOB</h3>
              
				   <div class = "card">
						<div class="col-md-12">
                        <div class="form-group">
                            <label class = "text-center card-header">Job Title:</label>
                            
                            <input type="text" name="name" class="form-control" placeholder="Job Title" />
                        </div>
                        <div class="form-group">
                            <label class = "text-center card-header">Job Category</label>
                            <select type="text" name="category" class="form-control" placeholder="Category">
                               <?php include 'categoryOptions.php';?> 
                            </select>
                        </div>
                        <div class="form-group">
                            <label class = "text-center card-header">Minimum Experiance</label>
                            <input type="text" name="minexp" class="form-control" placeholder="Minimum Expireince"  />
                        </div>
                        <div class="form-group">
                             <label class = "text-center card-header">Salary Budget</label>
                            <input type="text" name="salary" class="form-control" placeholder="Salary" />
                        </div>
                         <div class="form-group">
                             <label class = "text-center card-header">Job industry</label>
                             <select type="text" name="industry" class="form-control" placeholder="Industry" >
                                 <?php include 'industryOptions.php';?>
                             </select>
                        </div>
						<div id='question_type'> 
						<input type="hidden" class="form-control" id='questionIndex' name='questionIndex' value=0>
						<br>
						</div>
						<div id='question' style="display:none;" >
							<button name="submitPost" class = "btn btn-primary" class="btnContact pull-right" onClick="return addQuestion()">Add question</button>
						</div>

                      <div> 
                    
					
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class = "text-center card-header">Job requirements</label>
                            <textarea name="desc" class="form-control" placeholder="Description" style="height: 120px;"></textarea>
                        </div>
                         <div class="form-group">
                              <label class = "text-center card-header">Role</label>
                            <input type="text" name="role" class="form-control" placeholder="Role" />
                        </div>
                         <div class="form-group">
                              <label class = "text-center card-header">Place</label>
                            <input type="text" name="place" class="form-control" placeholder="Place" />
                        </div>
						
                         <div class="form-group">
                            <button type="submit" name="submitPost" class = "btn btn-primary" class="btnContact pull-right" > Post Job</button>
							<button type="" name="submitPost" class = "btn btn-primary" class="btnContact pull-right" >Preview</button>
                        </div>
						
                   
                </div>
				</div>
            </form>
			
			
</div>  
</div>
      
   
</div>
</div>      
</div>
</div>
    <!-- /#page-content-wrapper -->

  </div>
  <!-- /#wrapper -->

  <!-- Bootstrap core JavaScript -->
  <script src="../../assets/vendor/jquery/jquery.min.js"></script>
  <script src="../../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>

</body>

</html>
