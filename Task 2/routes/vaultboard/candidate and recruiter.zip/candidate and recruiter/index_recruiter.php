<?php
   session_start();
   include "includes/connection.php";
//   include('includes/slider.php');
   if(isset($_POST['recsubmit']))
   {
    $recemail=$_POST['rec_email'];
    $recpassword=$_POST['rec_password'];
    $sql ="select * from recruiter_basic WHERE email=:email and password=:usrpassword";
    $query= $pdo -> prepare("select * from recruiter_basic WHERE email=:email and password=:usrpassword");
    $query-> bindParam(':email', $recemail);
    $query-> bindParam(':usrpassword', $recpassword);
    $query-> execute();
    $result=$query->fetchall();
   
  foreach($result as $results)
  {
     if($results['first_name']=="NULL" || $results['first_name']==''){
      $recid = $results['id'];
      $_SESSION['recuserid']=$recid;
     	echo "<script type='text/javascript'>
     	document.location = 'recruiter/recbuildprofile/rec_basic_profile.php';</script>";
     }
    else{$recid = $results['id'];
    $_SESSION['recuserid']=$recid;
    echo "<script type='text/javascript'>
    document.location = 'recruiter/recbuildprofile/rec_view_profile.php'; </script>";
  } }
   echo "<script>alert('Invalid Details');
    document.location = 'index_recruiter.php';
    </script>";
  
   }
?>

<!DOCTYPE html>
<html>
<head>
  <title>Vault Board</title>
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
    <link rel="stylesheet" type="text/css" href="assets/bootstrap-tagsinput.css">
      <link rel="stylesheet" type="text/css" href="assets/bootstrap-multiselect.css">
      <link rel="stylesheet" type="text/css" href="assets/styles.css">
      <link rel="stylesheet" type="text/css" href="assets/bootstrap-tagsinput.css">
      <link rel="stylesheet" type="text/css" href="assets/bootstrap-tagsinput.css">
      <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>      
      <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>      
      <script type="text/javascript" src="../assets/bootstrap-multiselect.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
     <script type="text/javascript" src="../assets/bootstrap-tagsinput.js"></script>    
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
     <script type="text/javascript" src="assets/bootstrap-tagsinput.js"></script>
     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.css">
     <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/tagmanager/3.0.2/tagmanager.min.js"></script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
  <style type="text/css">
    body html{
      margin:0;
      padding:0;}
     .container1{
                background-image: url(images/home_background.jpg);
                background-repeat: no-repeat;
                padding-top: 0px;
                background-size: cover;
                background-position: center center;
                width: 100%;
                height: 100vh;
            }
             .overlay{
                background: #0000008a;
                width: 100%;
                height: 100vh;
                background-position: center center;
                top: 0;
                left: 0;
                z-index: 1;
            }
            .h1{
                font-size: 60px;
                color: #e5e5e5;
                text-align: center;
                margin-top: 125px;

            }
    }
            
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-dark">
  <a class="navbar-brand" href="#" style="padding-left: 0px;"><button class="btn text-light"><h5> VAULT BOARD</h5></button></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
 
<div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto"></ul>
        <ul class="nav navbar-nav navbar-right">
          <li class="nav-item">
          <a class="nav-link text-light font-weight-bold" href="index.php">Sign in as Candidate?</a>
          </li>
        </ul>

      </div>
</nav>

 <div class="container1">
  <div class="overlay">
  <div class="row">
    <div class="col col-lg-6 col-md-6 col-sm-6">
      <h1 class="h1" style="color:#e5e5e5">Vault Board</h1>
    </div>
    <div class="col col-lg-3 col-md-3 col-sm-4 ">
      <form action="#" method="post" class="form " enctype="multipart/form-data" style="font-size: 1.5em;margin-top: 95px;">
        <div class="form-group" >
          <label for="exampleInputEmail1" style="color:#e5e5e5">Email address</label>
          <input type="email" name="rec_email" class="form-control" id="rec_email" aria-describedby="emailHelp" placeholder="Enter email" style="background-color:#b2b2b2">
        </div>
        <div class="form-group">
          <label for="exampleInputPassword1" style="color:#e5e5e5">Password</label>
          <input type="password"  name = "rec_password"class="form-control" id="rec_password" placeholder="Enter Password" style="background-color:#b2b2b2">
        </div>   
        <div class="form-group" style="align-content: center;">
          <input type="submit" name="recsubmit" class="btn btn-success " >
          <p class="text-center text-light" style="font-size: 1em;"><small>Not Registered? <a href="rec_signup.php">Sign up now</a></small></p>
        </div>     
     </form>
    </div>
    </div>
  </div>
  </div>
<?php 
        include "footer.php";
        ?>
</body>
</html>