<?php
session_start();
   include "../../includes/connection.php";

if(strlen($_SESSION['userid'])==0)
{
header('location:../../index.php');
}
else{
	?>
    <!DOCTYPE html>
    <html>

    <head>
        <title>Edit Personal</title>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
        <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-tagsinput.css">
        <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-multiselect.css">
        <link rel="stylesheet" type="text/css" href="../../assets/bootstrap-tagsinput.css">
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="../../assets/bootstrap-multiselect.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
        <script type="text/javascript" src="../../assets/bootstrap-tagsinput.js"></script>
        <style type="text/css">
            .navbar li.active > a {
                background-color: #FF69B4;
            }
        </style>
    </head>

    <body>
        <nav class="navbar navbar-expand-lg navbar-expand-md navbar-light bg-dark">
            <a class="navbar-brand" href="#" style="padding-left: 0px;">
                <button class="btn text-light" style=" ">
                    <h5> VAULT BOARD</h5></button>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color: #FF69B4;">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="../home.php">
                            <button class="btn  text-light">Home</button><span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="#">
                            <button class="btn  text-light">Edit Profile</button><span class="sr-only">(current)</span></a>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="nav-item">
                        <form method="get" action="../../logout.php">
                            <button name="logout" type="submit" class="btn btn-danger text-light ">Logout</button>
                        </form>
                    </li>
                </ul>

            </div>
        </nav>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg">Edit Your Profile Here</button>

<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">

    </div>
  </div>
</div>
     <section id="tabs">
    <div class="container">
        <div class="row">
            <div class="col col-lg-12 col-md-12 col-sm-12 ">
                <nav>
                    <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                        <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-home" aria-selected="true">Personal</a>
                        <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-education" role="tab" aria-controls="nav-profile" aria-selected="false">Education</a>
                        <a class="nav-item nav-link" id="nav-contact-tab" data-toggle="tab" href="#nav-experience" role="tab" aria-controls="nav-contact" aria-selected="false">Experience</a>
                    </div>
                </nav>
                <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                        <?php
         include "../../includes/connection.php"; 
        $id = $_SESSION['userid'];
        $sqll=$pdo->prepare("select * from user_basics where id = :userid");
        $sqll->bindParam(':userid',$id);
        $sqll->execute();
        $resultt = $sqll->fetch(PDO::FETCH_OBJ);
        $sqlll=$pdo->prepare("select * from user_account where id = :userid");
        $sqlll->bindParam(':userid',$id);
        $sqlll->execute();
        $resulttt = $sqlll->fetch(PDO::FETCH_OBJ);
        if($resulttt->first_name=='NULL' || $resulttt->first_name==''){echo $resulttt
            ->first_name;echo "<script> alert('Please build your profile before editing');document.location='../buildprofile/basic_profile.php'; </script>";}

        ?>

            <div class="container">
                <form class="form-horizontal" style="margin-top: 50px;" action="edit_store.php" method="post" enctype="multipart/form-data">
                    <div class="float-right">
                        <div class="form-group">
                            <label  class="label" for="imagename">Profile Picture</label>
                            <div class="file-field">
                                <div class="mb-4">
                                    <?php 
                                    $id = $_SESSION['userid'];
                                    $con=mysqli_connect("localhost","root","","vault");
                                    $res=mysqli_query($con,"select * from user_basics where id= '$id'");
                                   while($row=mysqli_fetch_array($res))
                                   {
                                   echo '<img src="data:image/jpeg;base64,'.base64_encode($row['user_image'] ).'" height="200" width="200"/>';
                                   }
                                    ?>
                                </div>
                                <div class="d-flex justify-content-center">
                                    <div class="btn btn-mdb-color btn-rounded float-left">
                                        <input class=" inputtype" placeholder ="Change Profile Picture" type="file" name="image" id="image" accept="image/*" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col col-lg-6 col-md-12 col-sm-12">
                            <div class="form-group">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <label class="label"  for="firstname">First Name</label>
                                </div>
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <input type="text" id="frstname" class="form-control inputtype" required="required" maxlength="50" value="<?php echo $resulttt->first_name;?>" name="firstname" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <label  class="label" for="lastname">Last Name</label>
                                </div>
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <input type="text" id="lastname" value="<?php echo $resulttt->last_name;?>" required="required" class="form-control inputtype" maxlength="50" name="lastname" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <label class="label"  for="mobile">Mobile Number</label>
                                </div>
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <input type="number" required="required" class="form-control bfh-number inputtype" value="<?php echo $resulttt->mobile_number;?>" maxlength="10" id="mobile" name="mobile" />
                                    <br>
                                </div>
                            </div>
                            <br>
                            <div class="form-group">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <label class="label"  for="dob">Date of Birth</label>
                                </div>
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <input type="Date" id="dob" value="<?php  echo $resultt->dob;?>" class="form-control inputtype" required="required" name="dob">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <label class="label"  for="gender">Gender</label>
                                </div>
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <select class="form-control" value="" required="required" id="gender" name="gender">
                                        <option disabled selected value>
                                            <?php if ($resultt->gender=='M') {
                                                echo 'Male';
                                            }elseif ($resultt->gender=='F') {
                                                echo 'Female';
                                            }elseif ($resultt->gender=='O') {
                                                echo 'Other';
                                            } ?>
                                        </option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col col-lg-6 col-md-12 col-sm-12">

                            <div class="form-group">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <label class="label"  for="currentsalary">Current Salary</label>
                                </div>
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <input type="text" class="form-control bfh-number inputtype" value="<?php $salary = (float)$resultt->current_salary;echo $salary/12;?>" id="current_salary" required="required" min="0" maxlength="10" name="current_salary" /><span>*in Rs/-</span>
                                    <br>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input inputtype" type="radio" name="salarytype" id="monthly" value="monthly" required="required">
                                        <label class="form-check-label label" for="monthly">Monthly</label>

                                        <input class="form-check-input inputtype" type="radio" name="salarytype" id="annually" value="annually">
                                        <label class="form-check-label label" for="annually">Annually</label>
                                    </div>

                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <label class="form-check-label label" class="form-check-label" for="experienceyears">Total Experience</label>
                                </div>
                                <div class="col col-lg-12 col-md-12 col-sm-12">

                                    <input type="number" value="<?php echo $resultt->total_exp_yrs;?>" class="form-control inputtype" min="0" name="years">years</input>
                                    <input type="number" value="<?php echo $resultt->total_exp_months;?>" class="form-control inputtype" min="0" max="12" data-wrap="true" name="months" /><span>months</span></input>
                                    <br>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <label  class="label"  for="currentdesignation">Current Designation</label>
                                </div>
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <input type="text" id="currentdesignation" value="<?php echo $resultt->Current_designation;?>" class="form-control inputtype" required="required" maxlength="50" name="currentdesignation" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <label  class="label" for="currentcompany">Current Company</label>
                                </div>
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <input type="text" id="currentcompany" value="<?php echo $resultt->Current_company;?>" class="form-control inputtype" required="required" name="currentcompany" maxlength="50" />
                                    <br>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <label class="label"  for="currentsince">Current Since</label>
                                </div>
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <div class='input-group date' id='datetimepicker1'>
                                        <input type='date' value="<?php echo $resultt->Current_since;?>" required="required" name="currentsince" class="form-control inputtype">
                                        </input>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <label  class="label" for="skills"> Proffesional Skills</label>
                                </div>
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <select class="form-control" required="required" id="skills" name="skills[]" multiple="multiple">
                                        <option disabled selected value> -- Select Your Skills -- </option>
                                        <?php 
                                        $sql ="select * from skills";
                                        $query= $pdo->prepare($sql);
                                        $query-> execute();
                                        $results=$query->fetchall();

                                        foreach ($results as $result){echo $result['skill_set_name'];
                                        ?>
                                            <option value="<?php echo $result['id'];?>" <?php $sqli="select * from candidate_skills where user_account_id=:id" ; $queryi=$pdo->prepare($sqli); $userid = $_SESSION['userid']; $queryi->bindParam(':id',$userid); $queryi-> execute(); $resultsi=$queryi->fetchall(); foreach($resultsi as $resultii){if($resultii['skill_id']==$result['id']){echo "selected";}else{}} ?>>
                                                <?php echo $result['skill_set_name'];?>
                                            </option>
                                            <?php } ?>
                                    </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                        <input class=" inputtype" type="checkbox" id="is_mobile_notify" name="mobile_notification" value="mobile_notification">
                                        <label  class="label"  for="mobile_notify">Allow notifications to mobile??</label>

                                        <input class=" inputtype" type="checkbox" id="is_email_notify" name="email_notification" value="email_notification">
                                        <label  class="label"  for="email_notify">Allow notifications to email??</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col col-lg-10 col-md-12 col-sm-12">
                            <div class="form-group">
                                <div class="col col-lg-4 col-md-4 col-sm-12 ">
                                    <label  class="label" for="profilesummary">Profile Summary</label>
                                </div>
                                <div class="col col-lg-8 col-md-8 col-sm-12">
                                    <input type="textarea" class="form-control inputtype" id="profilesummary" value="<?php echo $resultt->Profile_summary;?>" name="profilesummary" rows="4" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                    <br>
                    <div class="row text-center">
                        <div class="col col-lg-4 col-md-4 col-sm-4"></div>
                        <div class="col col-lg-4 col-md-4 col-sm-4">
                            <input class="btn btn-success btn-lg btn-rounded inputtype" value="Save" name="editpersonalsubmit" type="submit" style="width: 100px" />
                        </div>
                        <div class="col col-lg-4 col-md-4 col-sm-4"></div>
                    </div>
                </form>
                    </div>
                    <div class="tab-pane fade" id="nav-education" role="tabpanel" aria-labelledby="nav-education-tab">
                        <div class="container">
                            <div class="row">
                                <div class="col col-lg-12 col-md-12 col-sm-12">
                                    <div id="accordion" style="width: 100% !important">
              <div class="row">
                <div class="col col-lg-12">
                    <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed text-center" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Doctorate/PhD
        </button>
      </h5>
    </div>
    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
      <div class="card-body">
        <div class="card-body">
            <?php $id=$_SESSION['userid'];
        $sql=$pdo->prepare("select * from education_detail where user_account_id=:id and degree_name=:degree_name
            ");
        $degree_name = "Doctorate/PhD";
        $sql->bindParam(':id',$id);
        $sql->bindParam(':degree_name',$degree_name);
        $sql->execute();
        $results = $sql->fetchall();?>
        <?php foreach ($results as $result) {
            if($result['degree_name']=='NULL' || $result['degree_name']==''){
                echo "<script>alert('Please enter your details before editing');document.location='../buildprofile/basiC_profile.php';</script>";
            }
        ?>
                <form method="post" action="edit_store.php">
                    
                <div class="form-group">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Major</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <select class="form-control"  required="required" name="major" id= "<?php echo $result['degree_name'];?>">
                    <option disabled selected value><?php echo $result['major'];?></option> 
                    </select>
                </div>
              </div>
                <div class="form-group">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">University</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="text" value="<?php echo $result['university'];?>" required="required" class="form-control inputtype" maxlength="100" name="university"/>
                </div>
                </div>
                <div class="form-group">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Start Date</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="Date" value="<?php echo $result['starting_date'];?>" class="form-control inputtype" required="required" name="startdate"/>
                </div>
                </div>
                <div class="form-group">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">End Date</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="Date" value="<?php echo $result['completion_date'];?>"  class="form-control inputtype" required="required" name="enddate"/>
                </div>
                </div>
                <div class="form-group">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Percentage</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['percentage'];?>" class="form-control inputtype" min="0.0" max="100.0" step=".01" required="required" name="percentage">
                </div>
                </div>
                <div class="form-group">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">CGPA</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['cgpa'];?>" class="form-control inputtype" min="0.0" max="10.0" step=".01" required="required" name="cgpa">
                </div>
                </div>
                <div class="form-group">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary"> Maximum CGPA</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['cgpa_max'];?>" class="form-control inputtype"  min="0.0" max="10.0" step=".01"  required="required" name="cgpamax"/>
                </div>
              </div>
              <div class="form-group">
                <div class="col col-md-4 col-lg-4 col-sm-4"></div>
                    <div class="col col-md-4 col-lg-4 col-sm-4">
                    <button class="btn btn-success btn-rounded" name="Doctorate/PhD" type="submit"> Change</button>
                </div>
              </div>
              </form><?php }?>
              </div>
      </div>
    </div>
  </div>
                </div>
              </div>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            Masters/Post-Graduation
        </button>
      </h5>
    </div>

    <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo" data-parent="#accordion">
        <div class="card-body">
            <?php $id=$_SESSION['userid'];
        $sql=$pdo->prepare("select * from education_detail where user_account_id=:id and degree_name=:degree_name
            ");
        $degree_name = "Masters/Post-Graduation";
        $sql->bindParam(':id',$id);
        $sql->bindParam(':degree_name',$degree_name);
        $sql->execute();
        $results = $sql->fetchall();?>
        <?php foreach ($results as $result) {
        ?>
                <form method="post" action="edit_store.php">
                    
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Major</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <select class="form-control"  required="required" name="major" id= "<?php echo $result['degree_name'];?>">
                    <option disabled selected value><?php echo $result['major'];?></option> 
                    </select>
                </div>
              </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">University</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="text" value="<?php echo $result['university'];?>" required="required" class="form-control inputtype" maxlength="100" name="university"/>
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Start Date</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="Date" value="<?php echo $result['starting_date'];?>" class="form-control inputtype" required="required" name="startdate"/>
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">End Date</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="Date" value="<?php echo $result['completion_date'];?>"  class="form-control inputtype" required="required" name="enddate"/>
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Percentage</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['percentage'];?>" class="form-control inputtype" min="0.0" max="100.0" step=".01" required="required" name="percentage">
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">CGPA</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['cgpa'];?>" class="form-control inputtype" min="0.0" max="10.0" step=".01" required="required" name="cgpa">
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary"> Maximum CGPA</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['cgpa_max'];?>" class="form-control inputtype"  min="0.0" max="10.0" step=".01"  required="required" name="cgpamax"/>
                </div>
              </div>
              <div class="row">
                <div class="col col-md-4 col-lg-4 col-sm-4"></div>
                    <div class="col col-md-4 col-lg-4 col-sm-4">
                    <button class="btn btn-success btn-rounded"name="Masters/Post-Graduation" type="submit"> Change</button>
                </div>
              </div>
              </form><?php }?>
              </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Graduation/Diploma
        </button>
      </h5>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
      <div class="card-body">
       <div class="card-body">
            <?php $id=$_SESSION['userid'];
        $sql=$pdo->prepare("select * from education_detail where user_account_id=:id and degree_name=:degree_name
            ");
        $degree_name = "Graduation/Diploma";
        $sql->bindParam(':id',$id);
        $sql->bindParam(':degree_name',$degree_name);
        $sql->execute();
        $results = $sql->fetchall();?>
        <?php foreach ($results as $result) {
        ?>
                <form method="post" action="edit_store.php">
                    
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Major</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <select class="form-control"  required="required" name="major" id= "<?php echo $result['degree_name'];?>">
                    <option disabled selected value><?php echo $result['major'];?></option> 
                    </select>
                </div>
              </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">University</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="text" value="<?php echo $result['university'];?>" required="required" class="form-control inputtype" maxlength="100" name="university"/>
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Start Date</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="Date" value="<?php echo $result['starting_date'];?>" class="form-control inputtype" required="required" name="startdate"/>
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">End Date</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="Date" value="<?php echo $result['completion_date'];?>"  class="form-control inputtype" required="required" name="enddate"/>
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Percentage</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['percentage'];?>" class="form-control inputtype" min="0.0" max="100.0" step=".01" required="required" name="percentage">
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">CGPA</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['cgpa'];?>" class="form-control inputtype" min="0.0" max="10.0" step=".01" required="required" name="cgpa">
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary"> Maximum CGPA</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['cgpa_max'];?>" class="form-control inputtype"  min="0.0" max="10.0" step=".01"  required="required" name="cgpamax"/>
                </div>
              </div>
              <div class="row text-center">
                <div class="col col-md-4 col-lg-4 col-sm-4"></div>
                    <div class="col col-md-4 col-lg-4 col-sm-4">
                    <button class="btn btn-success btn-rounded"name="Graduation/Diploma" type="submit"> Change</button>
                </div>
              </div>
              </form><?php }?>
              </div>
      </div>
    </div>
  </div>
    <div class="card">
    <div class="card-header" id="headingFour">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
          High School Diploma
        </button>
      </h5>
    </div>
    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
      <div class="card-body">
       <div class="card-body">
            <?php $id=$_SESSION['userid'];
        $sql=$pdo->prepare("select * from education_detail where user_account_id=:id and degree_name=:degree_name
            ");
        $degree_name = "12th";
        $sql->bindParam(':id',$id);
        $sql->bindParam(':degree_name',$degree_name);
        $sql->execute();
        $results = $sql->fetchall();?>
        <?php foreach ($results as $result) {
        ?>
                <form method="post" action="edit_store.php">
                    
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Major</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <select class="form-control"  required="required" name="major" id= "<?php echo $result['degree_name'];?>">
                    <option disabled selected value><?php echo $result['major'];?></option> 
                    </select>
                </div>
              </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">University</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="text" value="<?php echo $result['university'];?>" required="required" class="form-control inputtype" maxlength="100" name="university"/>
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Start Date</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="Date" value="<?php echo $result['starting_date'];?>" class="form-control inputtype" required="required" name="startdate"/>
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">End Date</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="Date" value="<?php echo $result['completion_date'];?>"  class="form-control inputtype" required="required" name="enddate"/>
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">Percentage</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['percentage'];?>" class="form-control inputtype" min="0.0" max="100.0" step=".01" required="required" name="percentage">
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary">CGPA</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['cgpa'];?>" class="form-control inputtype" min="0.0" max="10.0" step=".01" required="required" name="cgpa">
                </div>
                </div>
                <div class="row">
                <div class="col col-lg-4 col-md-4 col-sm-4">
                    <h5 class="card-title text-primary"> Maximum CGPA</h5>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <input type="number" value="<?php echo $result['cgpa_max'];?>" class="form-control inputtype"  min="0.0" max="10.0" step=".01"  required="required" name="cgpamax"/>
                </div>
              </div>
              <div class="row">
                <div class="col col-md-4 col-lg-4 col-sm-4"></div>
                    <div class="col col-md-4 col-lg-4 col-sm-4">
                    <button class="btn btn-success btn-rounded"name="12th" type="submit"> Change</button>
                </div>
              </div>
              </form><?php }?>
              </div>
      </div>
    </div>
  </div>
  
</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="nav-experience" role="tabpanel" aria-labelledby="nav-experience-tab">
                        <?php 
        $sql = $pdo->prepare("select * from experience_detail where user_account_id =:id");

        $id = $_SESSION['userid'];
        //echo $id;
        $sql->bindParam(':id',$id);
        $sql->execute();
        $results =  $sql->fetchall();
        foreach ($results as $result) {
            //echo $result['job_title'];
            if($result['job_title']==''){
                //echo $result['job_title'];
                echo "<script> alert('Post any Experiences before editing them !');document.location='../buildprofile/basic_profile.php';</script>";
            }
        ?>
        <div class="container" >
         <div class="card-group">
            <div class="card" style="font-size: 1.25em">
               <div class="card-header"><div class="row" style="padding-left: 10px;">
                  <p><h5 class="card-title text-primary text-lg">Job Title :</h5>
                   <?php echo $result['job_title'];?></p></div>
               </div>
               <div class="card-body">
                <div class="col col-lg-8 col-md-9 col-sm-10">
                  <div class="row">
                    <div class="col col-lg-4 col-md-6 col-sm-6"><h5 class="card-title text-primary ">Currently Working :</h5></div>
                    <div class="col col-lg-8 col-md-6 col-sm-6">
                        <p><?php if($result['is_current_job']=='N'){echo "No";}else{echo "Yes";}?></p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col col-lg-4 col-md-6 col-sm-6"><h5 class="card-title text-primary ">Start Date :</h5></div>
                    <div class="col col-lg-8 col-md-6 col-sm-6">
                        <p><?php echo $result['start_date'];?></p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col col-lg-4 col-md-6 col-sm-6"><h5 class="card-title text-primary ">End Date :</h5></div>
                    <div class="col col-lg-8 col-md-6 col-sm-6">
                        <p><?php echo $result['end_date'];?></p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col col-lg-4 col-md-6 col-sm-6"><h5 class="card-title text-primary ">Company Name : </h5></div>
                    <div class="col col-lg-8 col-md-6 col-sm-6">
                        <p><?php echo $result['company_name'];?></p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col col-lg-4 col-md-6 col-sm-6"><h5 class="card-title text-primary ">Working Location : </h5></div>
                    <div class="col col-lg-8 col-md-6 col-sm-6">
                        <?php echo $result['job_location_city'];?><?php echo ", ";?><?php echo $result['job_location_state'];?><?php echo ", ";?><?php echo $result['job_location_country'];?>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col col-lg-4 col-md-6 col-sm-6"><h5 class="card-title text-primary ">Role : </h5></div>
                    <div class="col col-lg-8 col-md-6 col-sm-6">
                        <?php echo $result['role'];?>
                    </div>
                  </div>
              </div> 
                                  
               </div>
               <div class="card-footer text-secondary">
                  <div class="row">
                    <div class="col col-lg-6 col-md-6 col-sm-6">
                        <form action="#" method="post"><button  class="btn btn-warning btn-rounded" type="submit" id="show" name="edit"  value="<?php echo $result['start_date'];?>">Edit</button></form>
                    </div>
                    <div class="col col-lg-6 col-md-6 col-sm-6">
                        <form action="#" method="post"><button class="btn btn-danger btn-rounded" type="submit" name="delete"  value="<?php echo $result['start_date'];?>">Delete</button></form>
                        <?php
                        if(isset($_POST['delete'])){
                            $del  =$_POST['delete'];
                            $sql = $pdo->prepare("delete from experience_detail where user_account_id = :id and start_date = :start_date");
                            $sql->bindParam(':id',$result['user_account_id']);
                            $sql->bindParam(':start_date',$del);
                            $sql->execute();
                            echo "<script>document.location='edit_basicprofile.php';</script>";
                        }
                        ?>
                    </div>
                  </div>
                  </div>
              </div>
           
         </div>
      </div><br>
<?php } ?>

<?php
if(isset($_POST['edit'])){
    $start_date = $_POST['edit'];
    //echo $start_date;
    $id = $_SESSION['userid'];
    $sql = $pdo->prepare("select * from experience_detail where user_account_id = :id and start_date =:start_date");
    $sql->bindParam(':id',$id);
    $sql->bindParam(':start_date',$start_date);
    $sql->execute();
    $result = $sql->fetchall();
    foreach ($result as $result) {
            echo '<div class="center ">
    <button class="text-light" id="close" style="font-style: bold ;float: right;background-color: red">X</button>
    <form style="margin-top: 50px;" action="#" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col col-lg-6 col-md-12 col-sm-12">
                        <div class="form-group">
                            <div class="col col-lg-4 col-md-4 col-sm-12"><label  class="label" for="jobtitle">Job Title</label></div>
                            <div class="col col-lg-8 col-md-8 col-sm-12">
                                <input type="text" class="form-control inputtype" required="required" maxlength="50" name="jobtitle" value="';echo $result["job_title"];echo '"/>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col col-lg-4 col-md-4 col-sm-12"><label  class="label" for="companyname">Company Name</label></div>
                            <div class="col col-lg-8 col-md-8 col-sm-12">
                                <input type="text" class="form-control inputtype" required="required" maxlength="50" name="companyname" value="';echo $result["company_name"];echo '"/>
                            </div>
                        </div>
                            
                        <div class="form-group">
                            <div class="col col-lg-4 col-md-4 col-sm-12"><label  class="label" for="startdate">Start Date</label></div>
                            <div class="col col-lg-8 col-md-8 col-sm-12">
                                <input type="Date" class="form-control inputtype" required="required" name="startdate" value="';echo $result["start_date"];echo '">
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col col-lg-4 col-md-4 col-sm-12">
                                <label class="label"  for="is_current">Are you currently working here?</label>
                            </div>
                            <div class="col col-lg-8 col-md-8 col-sm-12">
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input inputtype" type="radio" name="is_currently" id="currentyes" value="yes" required="required">
                                    <label class="label"  class="form-check-label" for="inlineRadio1">Yes</label>   
                                    <input class="form-check-input inputtype" type="radio" name="is_currently" id="currentno" value="no">
                                    <label class="label"  class="form-check-label" for="inlineRadio2">No</label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="col col-lg-4 col-md-4 col-sm-12">
                                <label  class="label" for="endate">End Date</label>
                            </div>
                            <div class="col col-lg-8 col-md-8 col-sm-12">
                                <input type="Date" id="enddate" class="form-control inputtype" required="required" name="enddate" value="';echo $result["end_date"];echo '">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col col-lg-4 col-md-4 col-sm-12"><label class="label"  for="city">City</label></div>
                            <div class="col col-lg-8 col-md-8 col-sm-12">
                                <input type="text" class="form-control inputtype" required="required" maxlength="50" name="city" value="';echo $result["job_location_city"];echo '"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col col-lg-4 col-md-4 col-sm-12"><label class="label"  for="state">State</label></div>
                            <div class="col col-lg-8 col-md-8 col-sm-12">
                                <input type="text" class="form-control inputtype" required="required" maxlength="50" name="state" value="';echo $result["job_location_state"];echo '"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col col-lg-4 col-md-4 col-sm-12"><label  class="label" for="Country">Country</label></div>
                            <div class="col col-lg-8 col-md-8 col-sm-12">
                                <input type="text" class="form-control inputtype" required="required" maxlength="50" name="country" value="';echo $result["job_location_country"];echo '"/>
                            </div>
                        </div>

                        <div class="form-group">
                    <div class="col col-lg-2 col-md-2 col-sm-4 text-center">
                        <label class="label"  for="role">Role</label>
                    </div>
                    <div class="col col-lg-10 col-md-10 col-sm-8">
                        <input type="textarea" class="form-control" name="role" id="role" rows="3" value="';echo $result["role"];echo '">
                    </div>
                    </div>
                    </div></div>
                    <div class="row">
                    
                    <div class="col col-lg-4 col-md-4 col-sm-4"><button class="btn btn-success btn-rounded" name="editexp" type="submit" value="';echo $result["start_date"];echo '">Confirm edit</button></div>
                    <div class="col col-lg-4 col-md-4 col-sm-4"></div>
                </div>
                
            </form>
</div>
';
    }

}
?>
<?php
if(isset($_POST['editexp'])){
     
        $jobtitle=$_POST['jobtitle'];
        $datt = $_POST['editexp'];
        $companyname=$_POST['companyname'];
        $is_currently=$_POST['is_currently'];
        if ($is_currently=='yes') {
            $is_currently = 'Y';
        }elseif ($is_currently=='no') {
            $is_currently = 'N';
        }
        $startdate=$_POST['startdate'];
        $enddate=$_POST['enddate'];
        $city=$_POST['city'];
        $state=$_POST['state'];
        $country=$_POST['country'];
        $role=$_POST['role'];
        $id = $_SESSION['userid'];
        //$job_type_id=1;
        $stmt=$pdo->prepare("update experience_detail set is_current_job =:is_current_job,job_title = :job_title,company_name = :company_name,job_location_city=:job_location_city,job_location_state=:job_location_state,job_location_country=:job_location_country,role =:role where user_account_id =:id and start_date = :start_date");
                $stmt->bindParam(':id', $id);
                $stmt->bindParam(':is_current_job', $is_currently);
                //$stmt->bindParam(':start_date', $startdate);
                //$stmt->bindParam(':end_date',$enddate);
                $stmt->bindParam(':job_title',$jobtitle);
                $stmt->bindParam(':company_name',$companyname);
                $stmt->bindParam(':job_location_city',$city);
                $stmt->bindParam(':job_location_state',$state);
                $stmt->bindParam(':job_location_country',$country);
                $stmt->bindParam(':role',$role);
                $stmt->bindParam(':start_date',$datt);
                //$stmt->bindParam(':job_type_id',$job_type_id);
                $stmt->execute();
                $_SESSION['userid']=$id;
    echo "<script type='text/javascript'>
     
     document.location='edit_basicprofile.php';</script>";

            }

?>

                    </div>
                </div>
            
            </div>
        </div>
    </div>
</section>

      
                <script type="text/javascript">
                    $(document).ready(function() {
                        $('#skills').multiselect();
                    });
                </script>

			<script>
            
		var optionArray1 = ["|","phd/doctorate|PhD/Doctorate","mphil|MPHIL","other|Other"];
		for(var option in optionArray1){
		var pair1 = optionArray1[option].split("|");
		var newOption = document.createElement("option");
		newOption.value = pair1[0];
		newOption.innerHTML = pair1[1];
		document.getElementById("Doctorate/PhD").options.add(newOption);
	
	}  
		var optionArray2 = ["|","CA|CA","CS|CS","DM|DM","ICWA(CMA)|ICWA(CMA)","Integrated PG|Integrated PG","LLM|LLM","M.A|M.A","M.Arch|M.Arch","M.Ch|M.Ch","M.Com|M.Com","M.Des|M.Des","M.Ed|M.Ed","M.Pharma|M.Pharma","MS/M.Sc(Science)|MS/M.Sc(Science)","M.Tech|M.Tech","MBA/PGDM|MBA/PGDM","MSC|MSC","MCM|MCM","MDS|MDS","MFA|MFA","Medical-Ms/Md|Medical-Ms/Md","MVSC|MVSC","PG Diploma|PG Diploma","OTHER|OTHER"];
		for(var option in optionArray2){
		var pair2 = optionArray2[option].split("|");
		var newOption = document.createElement("option");
		newOption.value = pair2[0];
		newOption.innerHTML = pair2[1];
		document.getElementById("Masters/Post-Graduation").options.add(newOption);
	
	} 
		var optionArray3 = ["|","B.A|B.A","B.Arch|B.Arch","B.B.A/B.M.S|B.B.A/B.M.S","B.Com|B.Com","B.Des|B.Des","B.Ed|B.Ed","B.EI.Ed|B.EI.Ed","B.P.Ed|B.P.Ed","B.Pharma|B.Pharma","B.Sc|B.Sc","B.Tech/B.E|B.Tech/B.E","B.U.M.S|B.U.M.S","BAMS|BAMS","BCA|BCA","BDS|BDS","BFA|BFA","BHM|BHM","BHMS|BHMS","BVSC|BVSC","Diploma|Diploma","LLB|LLB","MBBS|MBBS","OTHER|OTHER"];
		for(var option in optionArray3){
		var pair3 = optionArray3[option].split("|");
		var newOption = document.createElement("option");
		newOption.value = pair3[0];
		newOption.innerHTML = pair3[1];
		document.getElementById("Graduation/Diploma").options.add(newOption);
	
	}  
		var optionArray4 = ["|","CBSE|CBSE","CISCE|CISCE","National Open School|National Open School","Andhra Pradesh|Andhra Pradesh","Assam|Assam","Bihar|Bihar","Goa|Goa","Gujarat|Gujarat","Haryana|Haryana","Himachal Pradesh|Himachal Pradesh","Jammu & Kashmir|Jammu & Kashmir","Karnataka|Karnataka","Kerala|Kerala","Maharastra|Maharastra","Madhya Pradesh|Madhya Pradesh","Manipur|Manipur","Meghalaya|Meghalaya","Mizoram|Mizoram","Meghalaya|Meghalaya","Mizoram|Mizoram","Nagaland|Nagaland","Orissa|Orissa","Punjab|Punjab","Rajasthan|Rajasthan","Tamil Nadu|Tamil Nadu","Tripura|Tripura","Uttar Pradesh|Uttar Pradesh","West Bengal|West Bengal","OTHERS|OTHERS"];
		for(var option in optionArray4){
		var pair4 = optionArray4[option].split("|");
		var newOption = document.createElement("option");
		newOption.value = pair4[0];
		newOption.innerHTML = pair4[1];
		document.getElementById("12th").options.add(newOption);
		}
	



        </script>

<script type="text/javascript">
	$('#show').on('click',function(){$('.center').show();})
    $('#close').on('click',function(){$('.center').hide();})
</script>

    </body>

    </html>
    <?php }?>