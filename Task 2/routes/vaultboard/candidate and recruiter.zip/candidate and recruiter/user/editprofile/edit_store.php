<?php
session_start();
   include "../includes/connection.php";

if(strlen($_SESSION['userid'])==0)
{
header('location:../index.php');
}
else{
	if(isset($_POST['editpersonalsubmit'])){
	   	$id = $_SESSION['userid'];
        $firstname=$_POST['firstname'];
        $lastname=$_POST['lastname'];
        $mobile1=$_POST['mobile'];
        $dob=$_POST['dob'];
        $gender=$_POST['gender'];
        if ($gender=='male') {
        	$gender = 'M';
        }elseif ($gender=='female') {
        	$gender = 'F';
        }elseif ($gender=='other') {
        	$gender = 'O';
        }
        $current_salary=$_POST['current_salary'];
        $salarytype=$_POST['salarytype'];
        if ($salarytype=='monthly') {
        	$salarytype = 'M';
        	$current_salary = $current_salary*12;
        }elseif ($salarytype=='annually') {
        	$salarytype = 'A';
        }
        $years=$_POST['years'];
        $months=$_POST['months'];
        $currentdesignation=$_POST['currentdesignation'];
        $currentcompany=$_POST['currentcompany'];
        $currentsince=$_POST['currentsince'];
        //$mime = $_FILES['resume']['type'];
        //$data = file_get_contents($_FILES['resume']['tmp_name']);
        $profilesummary=$_POST['profilesummary'];
        $image = $_FILES['image']['tmp_name'];
        if(isset($_FILES['image'])){echo $_FILES['image']['tmp_name'];}
        //$check = getimagesize($_FILES["image"]["tmp_name"]);
        //$imgContent = addslashes(file_get_contents($image));
        $user_type_id=1;
        $sms_notification_active = "N";
        $email_notification_active = "N";
        //$currency = "Rupees";
        $email_notification = "N";
        if (isset($_POST['email_notification'])) {
			$email_notification = "Y";} 
		else {
		$email_notification = "N";}
		$mobile_notification = "N";
        if (isset($_POST['mobile_notification'])) {
			$mobile_notification = "Y";} 
		else {
		$mobile_notification = "N";}
		$delete_prev_skills= $pdo->prepare("delete from candidate_skills where user_account_id=:id");
        $delete_prev_skills->bindParam(':id',$id);
        $delete_prev_skills->execute();
        foreach($_POST['skills'] as $skill){
            $sql ="insert into candidate_skills(user_account_id,skill_id) values(:id,:skill_id) ";
            $query= $pdo -> prepare($sql);
            $query-> bindParam(':id', $id);
            $query-> bindParam(':skill_id', $skill);
            $query-> execute();
            }

        $stmt=$pdo->prepare("update user_basics set dob=:dob,gender=:gender,sms_notification_active=:sms_notification_active,email_notification_active=:email_notification_active,current_salary=:current_salary,is_annual_monthly=:is_annual_monthly,total_exp_yrs=:total_exp_yrs,total_exp_months=:total_exp_months,Current_designation=:Current_designation,Current_company=:Current_company,Current_since=:Current_since,Profile_summary=:Profile_summary where id=:id");
                $stmt->bindParam(':id', $id);
                //$stmt->bindParam(':user_type_id', $user_type_id);
                $stmt->bindParam(':dob', $dob);
                $stmt->bindParam(':gender', $gender);
                $stmt->bindParam(':sms_notification_active',$mobile_notification);
                $stmt->bindParam(':email_notification_active',$email_notification);
                //$stmt->bindParam(':user_image',$imgContent);
                $stmt->bindParam(':current_salary',$current_salary);
                $stmt->bindParam(':is_annual_monthly',$salarytype);
                //$stmt->bindParam(':currency',$currency);
                $stmt->bindParam(':total_exp_yrs',$years);
                $stmt->bindParam(':total_exp_months',$months);
                $stmt->bindParam(':Current_designation',$currentdesignation);
                $stmt->bindParam(':Current_company',$currentcompany);
                $stmt->bindParam(':Current_since',$currentsince);
                $stmt->bindParam(':Profile_summary',$profilesummary);
                //$stmt->bindParam(':resume',$data);
                //$stmt->bindParam(':resume_type',$mime);
                $stmt->execute();
       $sql1 = $pdo->prepare("update user_account set `first_name`=:first_name,`last_name`=:last_name,`mobile_number`=:mobile_number where id=:id");
       $sql1->bindParam(':first_name',$firstname);
       $sql1->bindParam(':last_name',$lastname);
       $sql1->bindParam(':mobile_number',$mobile1);
       $sql1->bindParam(':id',$id);
       $sql1->execute();
       $pdo=null;
       echo "<script>document.location = 'edit_basicprofile.php';</script>";}
       if(isset($_POST['submit'])){
        $major=$_POST['major'];
        $university=$_POST['university'];
        $startdate=$_POST['startdate'];
        $enddate=$_POST['enddate'];
        $cgpa=$_POST['cgpa'];
        $cgpamax=$_POST['cgpamax'];
        $id = $_SESSION['userid'];
        $percentage=$_POST['percentage'];
        $degree_name = $post;
        $stmt=$pdo->prepare("insert INTO education_detail(user_account_id,degree_name,major,university,starting_date,completion_date,percentage,cgpa,cgpa_max) VALUES (:id,:degree_name,:major,:university,:starting_date,:completion_date,:percentage,:cgpa,:cgpa_max)");
                $stmt->bindParam(':id', $id);
                $stmt->bindParam(':degree_name', $education);
                $stmt->bindParam(':major', $major);
                $stmt->bindParam(':university',$university);
                $stmt->bindParam(':starting_date',$startdate);
                $stmt->bindParam(':completion_date',$enddate);
                $stmt->bindParam(':percentage',$percentage);
                $stmt->bindParam(':cgpa',$cgpa);
                $stmt->bindParam(':cgpa_max',$cgpamax);
                $stmt->execute();
  
            }
    function updateTable($post)
    {
    	include "../includes/connection.php";
    	$major=$_POST['major'];
        $university=$_POST['university'];
        $starting_date=$_POST['startdate'];
        $completion_date=$_POST['enddate'];
        $percentage=$_POST['percentage'];
        $cgpa=$_POST['cgpa'];
        $cgpa_max=$_POST['cgpamax'];
        $id = $_SESSION['userid'];
        $degree_name = $post;
    	$updatesql = $pdo->prepare("update education_detail set major = :major,university = :university,starting_date = :starting_date,completion_date = :completion_date,percentage = :percentage,cgpa = :cgpa,cgpa_max = :cgpa_max where degree_name =:degree_name and user_account_id = :id");
    	$updatesql->bindParam(':major',$major);
    	$updatesql->bindParam(':university',$university);
    	$updatesql->bindParam(':starting_date',$starting_date);
    	$updatesql->bindParam(':completion_date',$completion_date);
    	$updatesql->bindParam(':percentage',$percentage);
    	$updatesql->bindParam(':cgpa',$cgpa);
    	$updatesql->bindParam(':cgpa_max',$cgpa_max);
    	$updatesql->bindParam(':degree_name',$degree_name);
    	$updatesql->bindParam(':id',$id);
    	$updatesql->execute();
    	echo "<script>document.location='edit_basicprofile.php';</script>";
    }
    if(isset($_POST['Doctorate/PhD']))
    {
    	$post = 'Doctorate/PhD';
    	updateTable($post);
    }   
    if(isset($_POST['Masters/Post-Graduation']))
    {
    	$post = 'Masters/Post-Graduation';
    	updateTable($post);
    }   
    if(isset($_POST['Graduation/Diploma']))
    {
    	$post = 'Graduation/Diploma';
    	updateTable($post);
    }   
    if(isset($_POST['12th']))
    {
    	$post = '12th';
    	echo $post;
    	updateTable($post);
    }   
    

}
?>