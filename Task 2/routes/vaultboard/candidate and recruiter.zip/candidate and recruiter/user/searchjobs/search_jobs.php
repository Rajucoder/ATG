<?php
session_start();
error_reporting(E_ERROR | E_PARSE);
   include "../../includes/connect.php";

if(strlen($_SESSION['userid'])==0)
{
header('location:../../index.php');
}
else{
  
  ?>
  <!doctype html>


<html>
<head>
       <!-- Global site tag (gtag.js) - Google Analytics -->


<meta charset="utf-8">

<link href="../../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<!--<link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">-->
<!-- Custom styles for this template -->
<link href="../../assets/css/simple-sidebar.css" rel="stylesheet"> 
<link href="../../assets/css/simpleGridTemplate.css" rel="stylesheet" type="text/css">
<link href="../../assets../assets/css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/Animate.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="../../assets/css/Animate.css" rel="stylesheet" type="text/css">
<link href="../../assets/css/animate.min.css" rel="stylesheet" type="text/css">
<link href="https://fonts.googleapis.com/css?family=Kodchasan" rel="stylesheet">
<style>
    .tiltContain{margin-top:0%;} 
    .btnTilt{height: 75px;background:rgba(225,225,225,0.2) ;  color:white; font-family: Comfortaa;}

    .textDarkShadow{
    text-shadow: 0px 0px 3px #000,3px 3px 5px #003333; 
}
    /*    #btn1,#btn2,#btn3,#btn4,#btn5,#btn6{display:none;}*/
</style>

<body onload="logoBeat()" style="font-family: 'Kodchasan', sans-serif;">
<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">Vaultboard</div>
      <div class="list-group list-group-flush">
        
      </div>
    </div>
    <!-- /#sidebar-wrapper -->

    <!-- Page Content -->
    <div id="page-content-wrapper">

      <nav class="navbar navbar-expand-lg navbar-light fixed-top bg-dark border-bottom">
        <button class="btn btn-primary" id="menu-toggle">Menu</button>

         <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color: #FF69B4;">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
           <li class="nav-item ">
           <a class="nav-link" href="../home.php"><button class="btn  text-light">Home</button><span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../buildprofile/view_profile.php"><button class="btn  text-light">Profile</button></a>
          </li>
          <li class="nav-item active">
            <a class="nav-link" href="#"><button class="btn  text-light">Search Jobs</button><span class="sr-only">(current)</span></a>
          </li>
          
          
        </ul>
        <ul class="nav navbar-nav navbar-right">
          
          <li class="nav-item">
            <form method="get" action="../../logout.php"> <button name="logout" type="submit" class="btn btn-danger text-light ">Logout</button></form>
          </li>
        </ul>

      </div>

        
      </nav>


<?php

?>
    
<!-- Main Container -->
<div class="container-fluid" style=" background-image: url('img/mainBackg.jpg'); background-position: center; background-size: cover; background-repeat: no-repeat; background-attachment: fixed;">

       

  
    <div class="hero" style=" color:darksmoke;" >
  
            <h1 style="padding:50px; font-size: 100px;"><strong>VAULTBOARD</strong></h1>
    <div style="width: 100%" class="row" >
    
      <div class="col-md-9"  >
                            <div style=" margin-top: 20px;">
                                <h1>Find jobs</h1>
                     <form class="example" action="applyjob.php">
  <div class="container">
  <div class="row">
        <div class="col-md-6">
            <div id="custom-search-input">
                <div class="input-group col-md-12">
                    <input type="text" class="form-control input-lg" placeholder="Search.." />
                    <span class="input-group-btn">
                        <button class="btn btn-info btn-lg" type="submit">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </span>
                </div>
            </div>
        </div>
  </div>
</div>
</form></div>
                            
                            <div class="container row">
                                <?php  $name=$category=$minexp=$salary=$industry=$desc=$role=$eType=$status=$msg="";


include '../../connect.php';
    
    $sql = "select * from post  order by date";  
       
        if(isset($_GET['q'])){
          $sql = "select *  from post where name LIKE '%".$_GET['q']."%' order by date";
        }
      if(isset($_GET['industry'])){
          $sql = "select * from post where industry='".$_GET['industry']."' order by date";
        }
      if(isset($_GET['category'])){
        $sql = "select * from post where category='".$_GET['category']."' order by date";
      }
     
      $result = $conn->query($sql);
      if($result->num_rows>0){
    while(  $row=$result->fetch_assoc()){
            $pid= $row['job_id'];
            $jobtitle= $row['role'];
            $category=$row['category'];
            $minexp=$row['minexp'];
            $salary=$row['salary'];
            $industry=$row['industry'];
            $desc=$row['desc'];
            $name=$row['name'];
      $status=$row['status'];
           
    ?>
                                <div class="col-md-4" style="margin: 20px; background: rgba(200,200,200,200);padding: 5px;box-shadow: 0px 0px 5px #003333">
                                    <h3 style="color: #2196F3"><?php echo $jobtitle;?></h3>
                                    <h5>By <?php echo $name;?></h5><br>
                                    <h5>Experiance required:<?php echo $minexp;?> years </h5>
                                    <h5>Salary:<?php echo $salary;?> </h5>
                                    <br>
                  <div class="pull-left">
                                    <button type="button" class="btn btn-danger btn-block" data-toggle="modal" data-target="#myModal">Apply</button>
                                
                  <a href="applyJob.php?id=<?php echo $pid;?>"><h3>Refer</h3></a>
                  </div>
                                </div>
                                
                                
                                
    <?php }}else{
                                    echo "Search returned no results";
                                } ?>
                            </div>
                            
                            
    </div>
    <div style=" height: 100vh; " class="col-md-3"> 
      <br><br> 
      <div style='padding:10px'>
              <h3>Jobs by Category</h3>
                             <form>
                            <div> 
                               
                            <select class="form-control" name='category'>
                                <?php include "categoryOptions.php";?>
                            </select><br>
                                <input class="btn btn-success pull-right" type="submit" value="Search"/>
                                </div>
                            </form>
                        </div><br><br>
                        <br><br> 
                        <div style='padding:10px'>
                            <h3>Jobs by Industry</h3>  
                            <form>
                            <select class="form-control" name='industry'>
                                <?php include "industryOptions.php";?>
                            </select><br>
                            <input class="btn btn-success pull-right" type="submit" value="Search"/>
                            </form>
                        </div> 
                        
                    </div>                     
    </div>                       
    
    
    
  
  
  
</div>
  
     
    
</div>
        
        
<!--first row -->

<script src="../../assets/vendor/jquery/jquery.min.js"></script>
  <script src="../../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Menu Toggle Script -->
  <script>
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  </script>
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="container" >
            <h3 style="color: #2196F3"><?php echo $jobtitle;?></h3>
            <h5 style="color: #2196F3">By <?php echo $name;?></h5>
            <h5>Experiance required:<?php echo $minexp;?> years </h5>
            <h5>Salary:<?php echo $salary;?> </h5>
            <h5>Category:<?php echo $category;?> </h5>
            <h5>Description:<?php echo $desc;?> </h5>
            <button class="btn btn-danger">Apply</button>
        </div>
      </div>  
</div>


</body>
</html>
<?php } ?>