<?php
session_start();
error_reporting(E_ERROR | E_PARSE);
   include "../../includes/connection.php";

if(strlen($_SESSION['userid'])==0)
{
header('location:../../index.php');
}
else{
	
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<title>View Profile</title>
		
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">
 		<link rel="stylesheet" type="text/css" href="../../assets/bootstrap-tagsinput.css">
    	<link rel="stylesheet" type="text/css" href="../../assets/bootstrap-multiselect.css">
	  	<link rel="stylesheet" type="text/css" href="../../assets/bootstrap-tagsinput.css">
	  	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
	   	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.1/bootstrap3-typeahead.min.js"></script>  
      	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
      	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
      	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>    	
    	<script type="text/javascript" src="../../assets/bootstrap-multiselect.js"></script>
    	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.js"></script>
 		<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
 		<script type="text/javascript" src="../../assets/bootstrap-tagsinput.js"></script>
 		<style type="text/css">
 			 .active {
              background-color: #FF69B4;
            }

 		</style>
	</head><script type="text/javascript"></script>
	<body>
		
		<nav class="navbar navbar-expand-lg navbar-light fixed-top bg-dark" style="font-size: 0.75em;">
		  <a class="navbar-brand" href="#" ><button class="btn text-light" style=" "><h5> VAULT BOARD</h5></button></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="background-color: #FF69B4;">
		    <span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
		    <ul class="navbar-nav mr-auto">
		       <li class="nav-item ">
		       <a class="nav-link" href="../home.php"><button class="btn  text-light">Home</button><span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item active">
		        <a class="nav-link" href="#"><button class="btn  text-light">Profile</button><span class="sr-only">(current)</span></a>
		      </li>
		      
		      
		    </ul>
		    <ul class="nav navbar-nav navbar-right">
		      <li class="nav-item">
		        <a class="nav-link" href="basic_profile.php"><button class="btn text-light ">Build Profile</button></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="../editprofile/edit_basicprofile.php"><button class="btn text-light ">Edit Profile</button></a>
		      </li>
		      <li class="nav-item">
		        <form method="get" action="../../logout.php"> <button name="logout" type="submit" class="btn btn-danger text-light ">Logout</button></form>
		      </li>
    		</ul>

		  </div>
		</nav>
<br>
		<div class="container" style="margin-top: 75px;">
				<div class="row">				
					<div class="col col-lg-3 col-md-3 col-sm-3 " style="font-size: 0.75em;">
						<div class="position-fixed">

							<?php 
							$id = $_SESSION['userid'];
							$con=mysqli_connect("localhost","root","","vault");
   							$res=mysqli_query($con,"select * from user_basics where id= '$id'");
						   while($row=mysqli_fetch_array($res))
						   {
						   echo '<img src="data:image/jpeg;base64,'.base64_encode($row['user_image'] ).'" height="200" width="200"/>';
						   }
	    					?>
							<?php 
							$id = $_SESSION['userid'];
	    					$sql = $pdo->prepare("select * from user_account where id = :id");
					    	$sql->bindParam(':id',$id);
					    	$sql->execute();
					    	$p = $sql->fetchall();
					    	foreach($p as $pgi){?>
							<p><h5><?php echo $pgi['first_name'];echo " ";echo $pgi['last_name'];}?></h5></p>
							<?php
							$score=0;
							$facebook = 0;
							$linkedin = 0;
							$experience = 0;
							$exp_yrs  = 0;
							$exp_months = 0;
							$exp_score = 0;
							$sql= $pdo->prepare("select * from user_basics where id=:id");
							$sql->bindParam(':id',$id);
							$sql->execute();
							$result = $sql->fetchall();
							foreach ($result as $result) {
								if($result['user_image']!='NULL' or $result['user_image']!=''){$score = $score+5;}
								if($result['resume']!='NULL' or $result['resume']!=''){$score = $score+25;}
								$exp_yrs = $result['total_exp_yrs']*365;
								$exp_months = $result['total_exp_months']*30;
								
							}
							$tot_exp = $exp_yrs + $exp_months;
							$sql= $pdo->query("select count(*) from education_detail where user_account_id='$id'");
							//$sql->bindParam(':id',$id);
							if($sql->fetchColumn()>0){$score = $score+10;}
							$expyrs = $pdo->prepare("select * from experience_detail where user_account_id = :id ");
							$expyrs->bindParam(':id',$id);
							$expyrs->execute();
							$result = $expyrs->fetchall();
							foreach($result as $result){
								$sd = new DateTime($result['start_date']);
								$ed = new DateTime($result['end_date']);
								$xpp = $sd->diff($ed);
								$xppp=$xpp->format('%R%a');
								$experience = $experience+$xppp;
							}
							$expert = ($experience/$tot_exp)*100;
							if ($expert<=40) {
								$exp_score = 0;
							}elseif ($expert<=75) {
								$exp_score = 10;
							}elseif ($expert>75) {
								$exp_score = 20;
							}
							$score = $score + $facebook + $linkedin + $exp_score;
							echo "<p>Profile Completed : ";echo $score;echo '% </p>';
							?>
							
							<ul class="list-group">
						 	 <a href="../editprofile/edit_basicprofile.php" class="list-group-item list-group-item-action">Edit Profile</a>
						 	 <a href="#recruiterview" class="list-group-item list-group-item-action active">Recruiter's View</a>
						 	 <a href="../searchjobs/search_jobs.php" class="list-group-item list-group-item-action">Search Jobs</a>
						 	 <a href="../appliedjobs/applied_jobs.php" class="list-group-item list-group-item-action">Applied Jobs</a>
						 	 <a href="" class="list-group-item list-group-item-action">Get Recommendations</a>
						 </ul>
						  
					</div>
				</div>
				<div class=" col col-lg-9 col-md-9 col-sm-9 ml-auto" style="padding-left:50px;font-size: 0.85em">
					  <div id="recruiterview" class="card">
					  	<div class="card-header">
					  	<div class="card-title" style="padding-left: 10px">
					  		
					  		<h5>Recruiter's view of your Profile
                             <button id="show" class="btn btn-primary btn-rounded float-right"> View Resume</button></h5>
					  	</div></div>
					  	<?php
					  	$id = $_SESSION['userid'];
					  	$sql = $pdo->prepare("select * from user_account where id = :id");
					  	$sql->bindParam(':id',$id);
					  	$sql->execute();
					  	$results = $sql->fetchall();
					  	foreach($results as $result){
					  		$basics = $pdo->prepare("select * from user_basics where id = :id");
					  		$basics->bindParam(':id',$id);
					  		$basics->execute();
					  		$basic = $basics->fetch(PDO::FETCH_OBJ);
					  		$education = $pdo->prepare("select * from education_detail where user_account_id = :id");
					  		$education->bindParam(':id',$id);
					  		$education->execute();
					  		$educate = $education->fetch(PDO::FETCH_OBJ);
					  		$experience = $pdo->prepare("select * from experience_detail where user_account_id = :id");
					  		$experience->bindParam(':id',$id);
					  		$experience->execute();
					  		$exp = $experience->fetch(PDO::FETCH_OBJ);
					  	?>
					    <div class="card-body">
					    	<div class="row">
					    		<div class="col col-lg-6 col-md-12 col-sm-12">
					    			<div class="row">
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					Current Designation :
					    				</div>
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					<?php echo $basic->Current_designation;?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					Current Company :
					    				</div>
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					<?php echo $basic->Current_company;?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					Last Designation :
					    				</div>
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					Last Company :
					    				</div>
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					Current Location :
					    				</div>
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					<?php echo $basic->current_location;?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					Preffered Location :
					    				</div>
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					Notice :
					    				</div>
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					
					    				</div>
					    			</div>

					    		</div>
					    		<div class="col col-lg-6 col-md-12 col-sm-12">
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-6 col-sm-6">
					    					CTC, EXP :
					    				</div>
					    				<div class="col col-lg-8 col-md-6 col-sm-6">
					    					<?php echo $basic->total_exp_yrs;echo "Yr ";echo $basic->total_exp_months;echo "M"?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-6 col-sm-6">
					    					Post Grad :
					    				</div>
					    				<div class="col col-lg-8 col-md-6 col-sm-6">
					    					<?php
					    					$id = $_SESSION['userid'];
					    					$degree = 'Masters/Post-Graduation';
					    					$pg = $pdo->prepare("select * from education_detail where degree_name = :degree_name and user_account_id = :id");
					    					$pg->bindParam(':degree_name',$degree);
					    					$pg->bindParam(':id',$id);
					    					$pg->execute();
					    					$p = $pg->fetchall();
					    					foreach($p as $pgi){
					    					echo $pgi['major'];echo " | ";echo $pgi['university'];echo " | ";echo $pgi['percentage'];echo " | ";echo "completed on:";echo $pgi['completion_date'];}?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-6 col-sm-6">
					    					<p>Graduation :</p>
					    				</div>
					    				<div class="col col-lg-8 col-md-6 col-sm-6">
					    					<?php
					    					$id = $_SESSION['userid'];
					    					$degree = 'Graduation/Diploma';
					    					$pg = $pdo->prepare("select * from education_detail where degree_name = :degree_name and user_account_id = :id");
					    					$pg->bindParam(':degree_name',$degree);
					    					$pg->bindParam(':id',$id);
					    					$pg->execute();
					    					$p = $pg->fetchall();
					    					foreach($p as $pgi){
					    					echo $pgi['major'];echo " | ";echo $pgi['university'];echo " | ";echo $pgi['percentage'];echo " | ";echo "completed on:";echo $pgi['completion_date'];}?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-6 col-sm-6">
					    					Email :
					    				</div>
					    				<div class="col col-lg-8 col-md-6 col-sm-6">
					    					<?php echo $result['email'];
					    					$emailverify=$result['email_verified'];
						                     if ($emailverify=='Y') {?>
						                     <i class="fas fa-check-circle"></i>
						                     <?php }else{ ?>
						                     <i class="fas fa-times-circle"></i>
						                     <?php }?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-6 col-sm-6">
					    					<p>Mobile :</p>
					    				</div>
					    				<div class="col col-lg-8 col-md-6 col-sm-6">
					    					<?php echo $result['mobile_number'];
					    					$phnverify=$result['mobile_verified'];
						                     if ($phnverify=='Y') {?>
						                     <i class="fas fa-check-circle"></i>
						                     <?php }else{ ?>
						                     <i class="fas fa-times-circle"></i>
						                     <?php }
						                        ?>
					    				</div>
					    			</div>
					    		</div>
					    	</div>
					    	<div class="row">
					    		<div class="col col-lg-12 col-md-12 col-sm-12">
					    			Key Skills : <?php $sql4 = $pdo->prepare("select * from candidate_skills where user_account_id=:userid");
                              $sql4->bindParam(':userid',$id);
                              $sql4->execute();
                              $results4 = $sql4->fetchall();
                              echo '<p class="text-secondary" >';
                              foreach ($results4 as $result4) {
                              $res4= $result4['skill_id'];
                              $sql5 = $pdo->prepare("select * from skills where id=:id");
                              $sql5->bindParam(':id',$res4);
                              $sql5->execute();
                              $results5 = $sql5->fetchall();
                              foreach ($results5 as $result5) {

                              echo $result5['skill_set_name'];echo ", ";}}echo '</p>';?>
					    		</div>
					    	</div>
					    </div>
					    <div class="card-footer">
					    	<div  class="showresume" >
					    	<?php 
							$id = $_SESSION['userid'];
	    					$sql = $pdo->prepare("select * from user_basics where id = :id");
					    	$sql->bindParam(':id',$id);
					    	$sql->execute();
					    	$p = $sql->fetchall();
					    	foreach($p as $pgi){?>
					    	<button id = 'close'>close</button>
					    	 <!--<iframe src="../../uploads/<?php echo $pgi['resume']?>"  style="width:100%; height: 100%;border: none;"></iframe>-->
					     <embed src="../../uploads/<?php echo $pgi['resume']; ?>" width='100%' height="450px" ><?php }?>
					    </div>
					    </div>
					  </div>
					  <br>
					  <div class="card">
					  	<div class="card-header"><div class="card-title" style="padding-left: 10px"><h5>Work Experience<a href="../editprofile/edit_basicprofile.php"><button class="btn btn-rounded btn-warning float-right" style="">Edit</button></a></h5></div></div>
					  	<?php
					  	$experience = $pdo->prepare("select * from experience_detail where user_account_id = :id");
					  		$experience->bindParam(':id',$id);
					  		$experience->execute();
					  		$exp = $experience->fetchall();
					  		foreach($exp as $ex){
					  	?>
					    <div class="card-body">
					    	<div class="row">
					    		<div class="col col-lg-6 col-md-12 col-sm-12">
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-6 col-sm-6">
					    					Designation :
					    				</div>
					    				<div class="col col-lg-8 col-md-6 col-sm-6">
					    					<?php echo $ex['job_title']; ?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-6 col-sm-6">
					    					Current Company :
					    				</div>
					    				<div class="col col-lg-8 col-md-6 col-sm-6">
					    					<?php echo $ex['company_name']; ?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-6 col-sm-6">
					    					Location :
					    				</div>
					    				<div class="col col-lg-8 col-md-6 col-sm-6">
					    					<?php echo $ex['job_location_city'];echo ", "; ?><?php echo $ex['job_location_state'];echo ", "; ?><?php echo $ex['job_location_country'];echo "." ?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-6 col-sm-6">
					    					<p>From : 
					    					To</p>
					    				</div>
					    				<div class="col col-lg-8 col-md-6 col-sm-6">
					    					<?php echo $ex['start_date']; ?><?php echo " : "; ?><?php echo $ex['end_date']; ?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-6 col-sm-6">
					    					Role :
					    				</div>
					    				<div class="col col-lg-8 col-md-6 col-sm-6">
					    					<?php echo $ex['role']; ?>
					    				</div>
					    			</div><hr>
					    		</div>
					    	</div>
					    </div><?php } ?>
					  </div>
					  <br>
					  <div class="card">
					  	<div class="card-header"><div class="card-title" style="padding-left: 10px"><h5>Education Profile<a href="../editprofile/edit_basicprofile.php"><button class="btn btn-rounded btn-warning float-right" style="">Edit</button></a></h5></div></div>
					  	<?php
					  	$education = $pdo->prepare("select * from education_detail where user_account_id = :id");
					  		$education->bindParam(':id',$id);
					  		$education->execute();
					  		$educat = $education->fetchall();
					  		foreach($educat as $edu){
					  	?>
					    <div class="card-body">
					    	<div class="row">
					    		<div class="col col-lg-6 col-md-12 col-sm-12">
					    			<div class="row">
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					Degree : Specialization
					    				</div>
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					<?php echo $edu['degree_name'];echo " : "; echo $edu['major'] ;?> 
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					College :
					    				</div>
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					<?php echo $edu['university']?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					From : To
					    				</div>
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					<?php echo $edu['starting_date'];echo " : ";echo $edu['completion_date']; ?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					Percentage :
					    				</div>
					    				<div class="col col-lg-6 col-md-6 col-sm-6">
					    					<?php echo $edu['percentage']; ?>
					    				</div>
					    			</div>
					    		</div>
					    	</div>
					    </div><?php }?>
					  </div>
					  <br>
					  <div class="card">
					  	<div class="card-header"><div class="card-title" style="padding-left: 10px"><h5>Personal Details <a href="../editprofile/edit_basicprofile.php"><button class="btn btn-rounded btn-warning float-right" style="">Edit</button></a></h5></div></div>
					    <div class="card-body">
					    	<div class="row">
					    		<div class="col col-lg-6 col-md-12 col-sm-12">
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-4 col-sm-12">
					    					Name :
					    				</div>
					    				<div class="col col-lg-8 col-md-8 col-sm-12">
					    					<?php echo $result['first_name'];echo " ";echo $result['last_name']; ?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-4 col-sm-12">
					    					Email :
					    				</div>
					    				<div class="col col-lg-8 col-md-8 col-sm-12">
					    					<?php echo $result['email']; ?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-4 col-sm-12">
					    					Mobile :
					    				</div>
					    				<div class="col col-lg-8 col-md-8 col-sm-12">
					    					<?php echo $result['mobile_number']; ?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-4 col-sm-12">
					    					Date Of Birth :
					    				</div>
					    				<div class="col col-lg-8 col-md-8 col-sm-12">
					    					<?php echo $basic->dob; ?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-4 col-sm-12">
					    					Gender :
					    				</div>
					    				<div class="col col-lg-8 col-md-8 col-sm-12">
					    					<?php echo $basic->gender; ?>
					    				</div>
					    			</div>
					    			<div class="row">
					    				<div class="col col-lg-4 col-md-4 col-sm-12">
					    					Current Salary :
					    				</div>
					    				<div class="col col-lg-8 col-md-8 col-sm-12">
					    					<p><?php echo $basic->current_salary; ?> p/a</p>
					    				</div>
					    			</div>
					    		</div>
					    	</div>
					    </div>
					  </div><?php } ?>
				</div>
			</div>
		</div>
		<script type="text/javascript">
  			$(document).ready(function(){
  				$('#skills').multiselect();
  			});
  		</script>
  		<?php 
        include "../../footer.php";
        ?>
        <script type="text/javascript">
        	$('.showresume').hide();
	$('#show').on('click',function(){$('.showresume').show();})
    $('#close').on('click',function(){$('.showresume').hide();})
</script>
  	</body>
  	</html>
				<?php }?>