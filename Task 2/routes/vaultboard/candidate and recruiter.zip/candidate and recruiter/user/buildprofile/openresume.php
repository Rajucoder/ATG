<?php 
function encode($inp)
{
	return strtr(base64_encode($inp),'+/=','-_,');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}
</style>
</head>
<body>
<h1>below is the word doc</h1>
<?php $url = "";?>
<iframe src='https://docs.google.com/viewer?url=http://vbsocial.000webhostapp.com/kumargaurav.doc&embedded=true' frameborder='0' height="800" width="800"> </iframe>

<div>
<iframe src="kumargaurav.docx">myDocument</iframe>
</div>


</body>
</html>