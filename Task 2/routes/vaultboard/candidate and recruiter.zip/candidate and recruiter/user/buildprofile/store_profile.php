w<?php
session_start();
include "../../includes/connection.php";
if(strlen($_SESSION['userid'])==0)
{
header('location:../../index.php');
}
else{
if(isset($_POST['personalsubmit'])){
$id = $_SESSION['userid'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$mobile1=$_POST['mobile'];
$dob=$_POST['dob'];
$gender=$_POST['gender'];
if ($gender=='male') {
$gender = 'M';
}elseif ($gender=='female') {
$gender = 'F';
}elseif ($gender=='other') {
$gender = 'O';
}
$current_salary=$_POST['current_salary'];
$salarytype=$_POST['salarytype'];
if ($salarytype=='monthly') {
$salarytype = 'M';
$current_salary = $current_salary*12;
}elseif ($salarytype=='annually') {
$salarytype = 'A';
}
$years=$_POST['years'];
$months=$_POST['months'];
$currentdesignation=$_POST['currentdesignation'];
$currentcompany=$_POST['currentcompany'];
$currentsince=$_POST['currentsince'];
$profilesummary=$_POST['profilesummary'];
$file = rand(1000,100000)."-".$_FILES['resume']['name'];
$file_loc = $_FILES['resume']['tmp_name'];
 $file_size = $_FILES['resume']['size'];
 $file_type = $_FILES['resume']['type'];
 $folderr="../../uploads/";
 move_uploaded_file($file_loc,$folderr.$file);



$user_type_id=1;
$sms_notification_active = "N";
$email_notification_active = "N";
$currency = "Rupees";
foreach($_POST['skills'] as $skill){
$sql ="insert into candidate_skills(user_account_id,skill_id) values(:id,:skill_id)";
$query= $pdo -> prepare($sql);
$query-> bindParam(':id', $id);
$query-> bindParam(':skill_id', $skill);
$query-> execute();
}
$stmt=$pdo->prepare("insert INTO user_basics(id,user_type_id,dob,gender,sms_notification_active,email_notification_active,current_salary,is_annual_monthly,currency,total_exp_yrs,total_exp_months,Current_designation,Current_company,Current_since,Profile_summary,resume,resume_type) VALUES (:id,:user_type_id,:dob, :gender, :sms_notification_active,:email_notification_active,:current_salary,:is_annual_monthly,:currency,:total_exp_yrs,:total_exp_months,:Current_designation,:Current_company,:Current_since,:Profile_summary,:resume,:resume_type)");
$stmt->bindParam(':id', $id);
$stmt->bindParam(':user_type_id', $user_type_id);
$stmt->bindParam(':dob', $dob);
$stmt->bindParam(':gender', $gender);
$stmt->bindParam(':sms_notification_active',$sms_notification_active);
$stmt->bindParam(':email_notification_active',$email_notification_active);
$stmt->bindParam(':current_salary',$current_salary);
$stmt->bindParam(':is_annual_monthly',$salarytype);
$stmt->bindParam(':currency',$currency);
$stmt->bindParam(':total_exp_yrs',$years);
$stmt->bindParam(':total_exp_months',$months);
$stmt->bindParam(':Current_designation',$currentdesignation);
$stmt->bindParam(':Current_company',$currentcompany);
$stmt->bindParam(':Current_since',$currentsince);
$stmt->bindParam(':Profile_summary',$profilesummary);
$stmt->bindParam(':resume',$file);
$stmt->bindParam(':resume_type',$file_type);
$stmt->execute();
$sql1 = $pdo->prepare("update user_account set `first_name`=:first_name,`last_name`=:last_name,`mobile_number`=:mobile_number where id=:id");
$sql1->bindParam(':first_name',$firstname);
$sql1->bindParam(':last_name',$lastname);
$sql1->bindParam(':mobile_number',$mobile1);
$sql1->bindParam(':id',$id);
$sql1->execute();
$con=mysqli_connect("localhost","root","","vault");
$proimage = addslashes(file_get_contents($_FILES['image']['tmp_name']));
$query = "update user_basics set user_image='$proimage' where id = $id";  
mysqli_query($con, $query); 
$_SESSION['userid']=$id;
echo "<script>document.location = 'view_profile.php';</script>";
}
if(isset($_POST['educationsubmit'])){
$education=$_POST['education'];
$major=$_POST['major'];
$university=$_POST['university'];
$startdate=$_POST['startdate'];
$enddate=$_POST['enddate'];
$cgpa=$_POST['cgpa'];
$cgpamax=$_POST['cgpamax'];
$id = $_SESSION['userid'];
$percentage=$_POST['percentage'];
$stmt=$pdo->prepare("insert INTO education_detail(user_account_id,degree_name,major,university,starting_date,completion_date,percentage,cgpa,cgpa_max) VALUES (:id,:degree_name,:major,:university,:starting_date,:completion_date,:percentage,:cgpa,:cgpa_max)");
$stmt->bindParam(':id', $id);
$stmt->bindParam(':degree_name', $education);
$stmt->bindParam(':major', $major);
$stmt->bindParam(':university',$university);
$stmt->bindParam(':starting_date',$startdate);
$stmt->bindParam(':completion_date',$enddate);
$stmt->bindParam(':percentage',$percentage);
$stmt->bindParam(':cgpa',$cgpa);
$stmt->bindParam(':cgpa_max',$cgpamax);
$stmt->execute();
$_SESSION['userid']=$id;
//echo "<script type='text/javascript'>alert('details filled'); </script>";
echo "<script>document.location = 'basic_profile.php';</script>";

}
if(isset($_POST['experiencesubmit'])){
$jobtitle=$_POST['jobtitle'];
$companyname=$_POST['companyname'];
$is_currently=$_POST['is_currently'];
if ($is_currently=='yes') {
$is_currently = 'Y';
}elseif ($is_currently=='no') {
$is_currently = 'N';
}
$startdate=$_POST['startdate'];
$enddate=$_POST['enddate'];
$city=$_POST['city'];
$state=$_POST['state'];
$country=$_POST['country'];
$role=$_POST['role'];
$id = $_SESSION['userid'];
$job_type_id=1;
$stmt=$pdo->prepare("insert INTO experience_detail(user_account_id,is_current_job,start_date,end_date,job_title,company_name,job_location_city,job_location_state,job_location_country,role,job_type_id) VALUES (:id,:is_current_job,:start_date,:end_date,:job_title,:company_name,:job_location_city,:job_location_state,:job_location_country,:role,:job_type_id)");
$stmt->bindParam(':id', $id);
$stmt->bindParam(':is_current_job', $is_currently);
$stmt->bindParam(':start_date', $startdate);
$stmt->bindParam(':end_date',$enddate);
$stmt->bindParam(':job_title',$jobtitle);
$stmt->bindParam(':company_name',$companyname);
$stmt->bindParam(':job_location_city',$city);
$stmt->bindParam(':job_location_state',$state);
$stmt->bindParam(':job_location_country',$country);
$stmt->bindParam(':role',$role);
$stmt->bindParam(':job_type_id',$job_type_id);
$stmt->execute();
$_SESSION['userid']=$id;
echo "<script type='text/javascript'>
alert('details filled');</script>";
echo "<script>document.location = 'basic_profile.php';</script>";

}
}?>
