<footer class="myfoot bg bg-dark" style="font-size: 0.95em;background-color:rgb(52,58,64)">
    <div class="container-fluid">
      <div class="row" >
      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 text-center">
          <div class="footer-contacts">
            <div class="footer-contact text-white">
              <i class="fa fa-phone-square fa-lg"></i> +91 
            </div>
            <div class="footer-contact text-center text-white"> 
             <span> <i class="fa fa-envelope-square fa-lg"></i> vaultboard@gmail.com</span>
            </div>
          </div>
        </div>
      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 text-center">
          <p class="text-white text-center">© 2019 Copyright: Vault Board<br>
           <a class="text-center text-white" href="#top">Go To Top <span><i class="fas fa-arrow-square-up fa-lg"></i></span></a>
        </div>
      <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 text-center">
          <div class="text-white">Get in touch with Vault Board at: <br>
            <a href="#"> <span  style="color: white"><i aria-hidden="true" class="fab fa-github-square fa-2x"></i></span></a>   <a href="#/">  <span style="color: white"><i class="fab fa-linkedin fa-2x"></i></i></span></a>  <a href="#"><span style="color: white"><i class="fab fa-facebook-square fa-2x"></i></span></a>

          </div>
        </div>
       </div>
    </div>
  </footer>